<?php
    if(!isset($con)) require "includes/con.php";
    if(!isset($user)) require "includes/auth.php";

    if(!in_array($user['role'], ['a', 't']))
    header('location: login.php');
    
    include "layouts/dashboard/dashboard_start.php";
?>
<div class="row p-4 px-5 bg-white">
    <h1 class="display-4">Online Examination System</h1>
    <p class="lead">
        Welcome to online examination system. Lorem ipsum dolor sit amet consectetur adipisicing elit. Doloremque reiciendis enim id blanditiis eos natus ratione laboriosam, et repellendus culpa quis ad! Vero, debitis! Minima modi velit exercitationem voluptatum cum! Lorem ipsum dolor, sit amet consectetur adipisicing elit. Consequuntur, et voluptatem. Ullam aperiam suscipit, perferendis maiores quae dolor, fuga libero accusantium et velit corrupti laboriosam est tenetur sint qui vel.
    </p>
    <hr class="my-5">
    <p class="lead">
        Lorem, ipsum dolor sit amet consectetur adipisicing elit. Ut vitae eos sunt temporibus dicta repellendus corporis odio alias expedita magni quasi, beatae voluptatem quo odit mollitia ratione possimus, error dolorum.
    </p>
</div>
<div class="row p-4 px-5 bg-light">
    <h1 class="display-4">About</h1>
    <p class="lead">
        Lorem ipsum dolor sit amet consectetur adipisicing elit. Sint eius molestias, maxime hic porro officia cumque! Illum culpa repellendus sapiente, debitis ullam modi ipsum aperiam, quidem veniam perspiciatis voluptatum eos?
    </p>
</div>
<?php
    include "layouts/dashboard/dashboard_end.php";
?>