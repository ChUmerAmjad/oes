<?php
  session_start();
  $user = [
    "id" => isset($_SESSION['id'])?$_SESSION['id']:0,
    "role" => isset($_SESSION['role'])?$_SESSION['role']:"g",
  ];

  function login($id, $role){
    if(!in_array($role, ["a", "t", "s"]))
    return false;

    global $_SESSION;
    global $user;
    $_SESSION['id'] = $user['id'] = $id;
    $_SESSION['role'] = $user['role'] = $role;
    // $_SESSION['id'] = $id;
    // $_SESSION['role'] = $role;
    // $user['id'] = $id;
    // $user['role'] = $role;
    return true;
  }

  function auth_arr(){
    global $user;
    global $con;
    return ($qry=mysqli_query($con, "SELECT * FROM users WHERE id='".$user['id']."';"))?mysqli_fetch_assoc($qry):false;
  }

  function logout(){
    global $_SESSION;
    unset($_SESSION['id']);
    unset($_SESSION['role']);

    $user['id'] = 0;
    $user['role'] = 'g';
    return true;
  }
?>