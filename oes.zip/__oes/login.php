<?php
  require "includes/con.php";
  require "includes/auth.php";

  if($user['role']!='g')
  header('location: index.php');

  if(isset($_POST['email']) && isset($_POST['password'])){
    extract($_POST);
    if($qry = mysqli_query($con, "SELECT * FROM users WHERE email='$email' AND password='$password';")){
      if(mysqli_num_rows($qry) > 0){
        $_user = mysqli_fetch_assoc($qry);
        login($_user['id'], $_user['role']);
        if($_user['role'] == 's')
        header("location: index.php");
        else header("location: dashboard.php");
      } else $err = "Incorrect email or password!";
    }
  }

  include "layouts/cross_form/cf_start.php";
?>

<form class="center" action="" method="POST">
  <h2>Please Sign In</h2>
  <input type="email" name="email" placeholder="email"/>
  <input type="password" name="password" placeholder="password"/>
  <button type="submit">Login</button>
  <?php
    if(isset($err) && !empty($err)){
      ?>
        <h4 style="color: red;"><?=$err?></h4>
      <?php
    } else {
      ?>
        <h2>&nbsp;</h2>
      <?php
    }
  ?>
</form>

<?php
  include "layouts/cross_form/cf_end.php";
?>