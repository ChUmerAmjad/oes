<li class="p-15 m-t-10"><a href="dashboard.php"
  class="btn d-block w-100 create-btn text-white no-block d-flex align-items-center"><i
  class="mdi mdi-view-dashboard"></i> <span class="hide-menu m-l-5">Dashboard</span> </a>
</li>
<?php
  if($user['role']=='a'){
    ?>
      <li class="sidebar-item"> <a class="sidebar-link waves-effect waves-dark sidebar-link"
        href="users.php" aria-expanded="false"><i
        class="mdi mdi-account-box"></i><span class="hide-menu">Users</span></a></li>
      <li class="sidebar-item"> <a class="sidebar-link waves-effect waves-dark sidebar-link"
        href="subjects.php" aria-expanded="false"><i class="mdi mdi-package-variant"></i><span
        class="hide-menu">Subjects</span></a></li>
      <li class="sidebar-item"> <a class="sidebar-link waves-effect waves-dark sidebar-link"
        href="courses.php" aria-expanded="false"><i class="mdi mdi-certificate"></i><span
        class="hide-menu">Courses</span></a></li>
      <li class="sidebar-item"> <a class="sidebar-link waves-effect waves-dark sidebar-link"
        href="student_courses.php" aria-expanded="false"><i class="mdi mdi-account-card-details"></i><span
        class="hide-menu">Student Courses</span></a></li>
      <li class="sidebar-item"> <a class="sidebar-link waves-effect waves-dark sidebar-link"
        href="exams.php" aria-expanded="false"><i class="mdi mdi-clipboard-text"></i><span
        class="hide-menu">Exams</span></a></li>
      <li class="sidebar-item"> <a class="sidebar-link waves-effect waves-dark sidebar-link"
        href="exam_submissions.php" aria-expanded="false"><i class="mdi mdi-clipboard-check"></i><span
        class="hide-menu">Submitted Exams</span></a></li>
    <?php
  }
  elseif($user['role']=='t'){
    ?>
      <li class="sidebar-item"> <a class="sidebar-link waves-effect waves-dark sidebar-link"
        href="teacher_exams.php" aria-expanded="false"><i class="mdi mdi-clipboard-text"></i><span
        class="hide-menu">Exams</span></a></li>
      <li class="sidebar-item"> <a class="sidebar-link waves-effect waves-dark sidebar-link"
        href="teacher_exam_submissions.php" aria-expanded="false"><i class="mdi mdi-clipboard-check"></i><span
        class="hide-menu">Submitted Exams</span></a></li>
    <?php
  }
?>
<li class="sidebar-item"> <a class="sidebar-link waves-effect waves-dark sidebar-link"
  href="profile.php" aria-expanded="false"><i class="mdi mdi-account"></i><span
  class="hide-menu">Profile</span></a></li>
<li class="sidebar-item"> <a class="sidebar-link waves-effect waves-dark sidebar-link"
  href="logout.php" aria-expanded="false"><i class="mdi mdi-logout"></i><span
  class="hide-menu">Logout</span></a></li>