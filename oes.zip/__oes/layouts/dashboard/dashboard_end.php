      </div>
    <script src="dashboard_assets/assets/libs/jquery/dist/jquery.min.js"></script>
    <script src="dashboard_assets/assets/libs/bootstrap/dist/js/bootstrap.bundle.min.js"></script>
    <script src="dashboard_assets/dist/js/app-style-switcher.js"></script>
    <script src="dashboard_assets/dist/js/waves.js"></script>
    <script src="dashboard_assets/dist/js/sidebarmenu.js"></script>
    <script src="dashboard_assets/dist/js/custom.js"></script>
    <script src="dashboard_assets/assets/libs/chartist/dist/chartist.min.js"></script>
    <script src="dashboard_assets/assets/libs/chartist-plugin-tooltips/dist/chartist-plugin-tooltip.min.js"></script>
    <script src="dashboard_assets/dist/js/pages/dashboards/dashboard1.js"></script>

    <!-- Data tables -->
    <script src="data_table_assets/js/jquery-3.5.1.js"></script>
    <script src="data_table_assets/js/jquery.dataTables.min.js"></script>
    <script src="data_table_assets/js/dataTables.bootstrap4.min.js"></script>
    <script src="data_table_assets/js/dataTables.buttons.min.js"></script>
    <script src="data_table_assets/js/buttons.bootstrap4.min.js"></script>
    <script src="data_table_assets/js/jszip.min.js"></script>
    <script src="data_table_assets/js/pdfmake.min.js"></script>
    <script src="data_table_assets/js/vfs_fonts.js"></script>
    <script src="data_table_assets/js/buttons.html5.min.js"></script>
    <script src="data_table_assets/js/buttons.print.min.js"></script>
    <script src="data_table_assets/js/buttons.colVis.min.js"></script>
    <script>
      $(document).ready(function() {
        var table = $('.data_table').DataTable( {
          lengthChange: false,
          buttons: [ 'copy', 'excel', 'pdf', 'colvis' ]
        });
        table.buttons()
        .container()
          // .appendTo( '#data_table_wrapper .col-md-6:eq(0)' );
          .appendTo( '.dataTables_wrapper > .row > .col-md-6:first-child' );

        // if(document.getElementById("data_table2")){
        //   table = $('#data_table').DataTable( {
        //     lengthChange: false,
        //     buttons: [ 'copy', 'excel', 'pdf', 'colvis' ]
        //   });
        //   table.buttons()
        //   .container()
        //     .appendTo( '#data_table2_wrapper .col-md-6:eq(0)' );
        // }
      });
    </script>
  </body>
</html>