CREATE DATABASE IF NOT EXISTS oes;
USE oes;

CREATE TABLE IF NOT EXISTS users(id INT PRIMARY KEY AUTO_INCREMENT, email VARCHAR(100) NOT NULL, password VARCHAR(50) NOT NULL, role VARCHAR(1) NOT NULL DEFAULT 's', fname VARCHAR(100) NOT NULL, lname VARCHAR(100) NOT NULL, cnic VARCHAR(15) NOT NULL);
/*
  Roles:
    a => Admin
    t => Teacher
    s => Student
*/

CREATE TABLE IF NOT EXISTS courses(id INT PRIMARY KEY AUTO_INCREMENT, title VARCHAR(100) NOT NULL);
CREATE TABLE IF NOT EXISTS student_courses(id INT PRIMARY KEY AUTO_INCREMENT, student_id INT NOT NULL, course_id INT NOT NULL);

CREATE TABLE IF NOT EXISTS subjects(id INT PRIMARY KEY AUTO_INCREMENT, subject VARCHAR(100) NOT NULL);

CREATE TABLE IF NOT EXISTS exams(id INT PRIMARY KEY AUTO_INCREMENT, teacher_id iNT NOT NULL, course_id INT NOT NULL, subject_id INT NOT NULL, exam_type VARCHAR(1) NOT NULL DEFAULT 'b', subjective_marks INT NOT NULL, mcq_marks INT NOT NULL DEFAULT 1, start_date DATE NOT NULL, end_date DATE NOT NULL, time_h INT NOT NULL DEFAULT 0, time_m INT NOT NULL DEFAULT 0, time_s INT NOT NULL DEFAULT 0, status INT NOT NULL DEFAULT 0);
/*
  Exam Types:
    a => Annual
    s => Supply
    b => Both
*/
/*
  Status:
    0 => Hidden
    1 => Active
    2 => Closed
*/
CREATE TABLE IF NOT EXISTS exam_questions(id INT PRIMARY KEY AUTO_INCREMENT, exam_id iNT NOT NULL, question VARCHAR(254) NOT NULL);
CREATE TABLE IF NOT EXISTS exam_mcqs(id INT PRIMARY KEY AUTO_INCREMENT, exam_id iNT NOT NULL, question VARCHAR(254) NOT NULL, option_a VARCHAR(100) NOT NULL, option_b VARCHAR(100) NOT NULL, option_c VARCHAR(100) NOT NULL, option_d VARCHAR(100) NOT NULL, correct VARCHAR(1) DEFAULT 'a');
/*
  Correct:
    a => A
    b => B
    c => C
    d => D
*/

CREATE TABLE IF NOT EXISTS exams_submissions(id INT PRIMARY KEY AUTO_INCREMENT, exam_id INT NOT NULL, type VARCHAR(1) NOT NULL, student_id iNT NOT NULL, marks FLOAT NOT NULL DEFAULT 0, date DATE NOT NULL DEFAULT CURRENT_DATE, time TIME NOT NULL DEFAULT CURRENT_TIME, submission_status INT NOT NULL DEFAULT 0, grading_status INT NOT NULL DEFAULT 0, lm_date DATE NOT NULL DEFAULT CURRENT_DATE, lm_time TIME NOT NULL DEFAULT CURRENT_TIME, submission_comment VARCHAR(300) NOT NULL DEFAULT '');
/*
  Submission Statuses:
    0 => Not Submitted
    1 => Submitted
*/
/*
  Grading Statuses:
    0 => Pending
    1 => Marked
*/
CREATE TABLE IF NOT EXISTS exam_submission_files(id INT PRIMARY KEY AUTO_INCREMENT, exam_submission_id INT NOT NULL, file_src VARCHAR(254) NOT NULL);
CREATE TABLE IF NOT EXISTS exam_submission_mcqs(id INT PRIMARY KEY AUTO_INCREMENT, exam_submission_id INT NOT NULL, question_id INT NOT NULL, selected_option VARCHAR(1) NOT NULL DEFAULT 'a');

INSERT INTO users(email, password, role, fname, lname, cnic) VALUES ('admin@example.com', 'admin', 'a', 'Admin', 'Name', '31000-0000000-0');