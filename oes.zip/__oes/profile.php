<?php
  if(!isset($con)) require "includes/con.php";
  if(!isset($user)) require "includes/auth.php";

  if(!in_array($user['role'], ['a', 't', 's']))
  header('location: login.php');

  // Update User Profile
  if(isset($_POST['update_profile'])){
    if($user['role']!='s'){
      extract($_POST);
      if(!mysqli_query($con, "UPDATE users SET fname='$fname', lname='$lname', cnic='$cnic' WHERE id='".$user['id']."';"))
      die("Unable to update profile!");
    }
  }

  // Change Password
  if(isset($_POST['change_password'])){
    if(isset($_POST['opassword']) && isset($_POST['npassword']) && isset($_POST['cpassword'])){
      if($_POST['npassword'] == $_POST['cpassword']){
        if(($qry=mysqli_query($con, "SELECT id FROM users WHERE id='".$user['id']."' AND password='".$_POST['opassword']."';")) && (mysqli_num_rows($qry)>0)){
          if(mysqli_query($con, "UPDATE users SET password='".$_POST['npassword']."' WHERE id='".$user['id']."';"))
          $scc = "Password Updated Successfully";
          else $err = "Unable to Update Password!";
        } else $err = "Incorrect Old Password!";
      } else $err = "Password not matched!";
    } else $err = "Invalid Data!";
  }

  // Fetch User Profile
  if($qry=mysqli_query($con, "SELECT * FROM users WHERE id='".$user['id']."';"))
  extract(mysqli_fetch_assoc($qry));
  else die("Unable to fetch user from database");

  require "layouts/student/layout_start.php";
?>

<div class="row p-5">
  <div class="col-12">
    <?php
      if(isset($err)){
        ?>
          <div class="alert m-3 alert-danger" onclick="this.classList.add('d-none');"><?=$err?></div>
        <?php
      }
      elseif(isset($scc)){
        ?>
          <div class="alert m-3 alert-success" onclick="this.classList.add('d-none');"><?=$scc?></div>
        <?php
      }
    ?>
    <h1>Profile</h1>
    <p class="lead">
      Manager Your Profile in following
    </p>
  </div>
  <div class="col-12 mt-5 bg-light p-4 border">
    <h2>View<?=$role=='s'?"":" / Edit"?> Profile</h2>
    <p class="lead text-muted">
      View<?=$role=='s'?"":" / Edit"?> Your Profile
    </p>
    <form action="" method="post" class="mt-5">
      <input type="hidden" name="update_profile" value="true">
      <div class="row">
        <div class="col-md-6">
          <div class="form-group">
            <label for="fname">First Name</label>
            <input type="text" name="fname" id="fname" value="<?=$fname?>" class="form-control" placeholder="First Name" <?=$role=='s'?"disabled":"required"?>>
          </div>
        </div>
        <div class="col-md-6">
          <div class="form-group">
            <label for="fname">Last Name</label>
            <input type="text" name="lname" id="lname" value="<?=$lname?>" class="form-control" placeholder="Last Name" <?=$role=='s'?"disabled":"required"?>>
          </div>
        </div>
        <div class="col-md-6">
          <div class="form-group">
            <label for="fname">Email Address</label>
            <input type="text" name="email" id="email" value="<?=$email?>" class="form-control" placeholder="Email Address" disabled>
          </div>
        </div>
        <div class="col-md-6">
          <div class="form-group">
            <label for="cnic">CNIC</label>
            <input type="text" name="cnic" id="cnic" value="<?=$cnic?>" class="form-control" placeholder="CNIC" <?=$role=='s'?"disabled":"required"?>>
          </div>
        </div>
        <div class="col-12">
          <button type="submit" class="btn btn-success"<?=$role=='s'?" disabled":""?>>Update</button>
        </div>
      </div>
    </form>
  </div>
  <div class="col-12 mt-5 bg-light p-4 border">
    <h2>Change Password</h2>
    <p class="lead text-muted">
      Change your Password
    </p>
    <form action="" method="post" class="mt-5">
      <input type="hidden" name="change_password" value="true">
      <div class="row">
        <div class="col-md-12">
          <div class="form-group">
            <label for="opassword">Old Password</label>
            <input type="password" name="opassword" id="opassword" class="form-control" placeholder="Old Password" required>
          </div>
        </div>
        <div class="col-md-6">
          <div class="form-group">
            <label for="npassword">New Password</label>
            <input type="password" name="npassword" id="npassword" class="form-control" placeholder="New Password" required>
          </div>
        </div>
        <div class="col-md-6">
          <div class="form-group">
            <label for="cpassword">Confirm Password</label>
            <input type="password" name="cpassword" id="cpassword" class="form-control" placeholder="Confirm Password" required>
          </div>
        </div>
        <div class="col-12">
          <button type="submit" class="btn btn-success">Change</button>
          <button type="reset" class="btn btn-secondary">Clear</button>
        </div>
      </div>
    </form>
  </div>
</div>

<?php
  require "layouts/student/layout_end.php";
?>