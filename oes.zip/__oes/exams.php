<?php
  if(!isset($con)) require "includes/con.php";
  if(!isset($user)) require "includes/auth.php";

  if(!in_array($user['role'], ['a', 't']))
  header('location: login.php');
  elseif($user['role']!='a')
  header('location: dashboard.php');

  // Add Exam
  if(isset($_POST['add_exam'])){
    extract($_POST);
    if(mysqli_query($con, $sql="INSERT INTO exams(teacher_id, course_id, subject_id, exam_type, start_date, end_date, time_h, time_m, time_s, status, mcq_marks, subjective_marks) VALUES ('$teacher', '$course', '$subject', '$exam_type', '$start_date', '$end_date', '$time_h', '$time_m', '$time_s', $status, $mcq_marks, $subjective_marks);"))
    $msg = [
      "type" => "success",
      "msg" => "Exam Added Successfully!",
    ];
    else $msg = [
      "type" => "danger",
      "msg" => "Error while Inserting exam!",
    ];
  }

  // Add Exam Question
  if(isset($_POST['add_exam_question'])){
    extract($_POST);
    if(mysqli_query($con, $sql="INSERT INTO exam_questions(exam_id, question) VALUES ('$exam_id', '$question');"))
    $msg = [
      "type" => "success",
      "msg" => "Exam Question Added Successfully!",
    ];
    else $msg = [
      "type" => "danger",
      "msg" => "Error while Inserting exam question!",
    ];
  }

  // Add Exam MCQ
  if(isset($_POST['add_exam_mcq'])){
    extract($_POST);
    if(mysqli_query($con, $sql="INSERT INTO exam_mcqs(exam_id, question, option_a, option_b, option_c, option_d, correct) VALUES ('$exam_id', '$question', '$option_a', '$option_b', '$option_c', '$option_d', '$correct');"))
    $msg = [
      "type" => "success",
      "msg" => "Exam MCQ Added Successfully!",
    ];
    else $msg = [
      "type" => "danger",
      "msg" => "Error while Inserting Exam MCQ!",
    ];
  }

  // Update exam
  if(isset($_POST['update_exam_id'])){
    extract($_POST);
    if($qry=mysqli_query($con, "SELECT * FROM exams WHERE id=$update_exam_id;")){
      if(mysqli_num_rows($qry) == 1){
        if(mysqli_query($con, "UPDATE exams SET teacher_id='$teacher', course_id='$course', subject_id='$subject', exam_type='$exam_type', start_date='$start_date', end_date='$end_date', time_h='$time_h', time_m='$time_m', time_s='$time_s', status='$status', mcq_marks='$mcq_marks', subjective_marks='$subjective_marks' WHERE id=$update_exam_id;"))
        $msg = [
          "type" => "success",
          "msg" => "Exam Updated Successfully!",
        ];
        else $msg = [
          "type" => "danger",
          "msg" => "Error while Updating exam!".mysqli_error($con),
        ];
      } else $msg = [
        "type" => "danger",
        "msg" => "Exam Does not Exists!",
      ];
    } else $msg = [
      "type" => "danger",
      "msg" => "Unable to Confirm Exam!",
    ];
  }

  // Update Exam Question
  if(isset($_POST['update_exam_mcq_id'])){
    extract($_POST);
    if($qry=mysqli_query($con, "SELECT * FROM exam_mcqs WHERE id=$update_exam_mcq_id;")){
      if(mysqli_num_rows($qry) == 1){
        if(mysqli_query($con, "UPDATE exam_mcqs SET question='$question', option_a='$option_a', option_b='$option_b', option_c='$option_c', option_d='$option_d', correct='$correct' WHERE id=$update_exam_mcq_id;"))
        $msg = [
          "type" => "success",
          "msg" => "Exam MCQ Updated Successfully!",
        ];
        else $msg = [
          "type" => "danger",
          "msg" => "Error while Updating Exam MCQ!",
        ];
      } else $msg = [
        "type" => "danger",
        "msg" => "Exam MCQ Does not Exists!",
      ];
    } else $msg = [
      "type" => "danger",
      "msg" => "Unable to Confirm Exam MCQ!",
    ];
  }

  // Update Exam MCQ
  if(isset($_POST['update_exam_question_id'])){
    extract($_POST);
    if($qry=mysqli_query($con, "SELECT * FROM exam_questions WHERE id=$update_exam_question_id;")){
      if(mysqli_num_rows($qry) == 1){
        if(mysqli_query($con, "UPDATE exam_questions SET question='$question' WHERE id=$update_exam_question_id;"))
        $msg = [
          "type" => "success",
          "msg" => "Exam Question Updated Successfully!",
        ];
        else $msg = [
          "type" => "danger",
          "msg" => "Error while Updating Exam Question!",
        ];
      } else $msg = [
        "type" => "danger",
        "msg" => "Exam Question Does not Exists!",
      ];
    } else $msg = [
      "type" => "danger",
      "msg" => "Unable to Confirm Exam Question!",
    ];
  }

  // Delete Exam
  if(isset($_POST['delete_exam_id'])){
    extract($_POST);
    if($qry=mysqli_query($con, "SELECT * FROM exams WHERE id=$delete_exam_id;")){
      if(mysqli_num_rows($qry) == 1){
        if(mysqli_query($con, "DELETE FROM exams WHERE id=$delete_exam_id;"))
        $msg = [
          "type" => "success",
          "msg" => "Exam Deleted Successfully!",
        ];
        else $msg = [
          "type" => "danger",
          "msg" => "Error while Deleting exam!",
        ];
      } else $msg = [
        "type" => "danger",
        "msg" => "Exam Does not Exists!",
      ];
    } else $msg = [
      "type" => "danger",
      "msg" => "Unable to Confirm Exam!",
    ];
  }

  // Delete Exam Question
  if(isset($_POST['delete_exam_question_id'])){
    extract($_POST);
    if($qry=mysqli_query($con, "SELECT * FROM exam_questions WHERE id=$delete_exam_question_id;")){
      if(mysqli_num_rows($qry) == 1){
        if(mysqli_query($con, "DELETE FROM exam_questions WHERE id=$delete_exam_question_id;"))
        $msg = [
          "type" => "success",
          "msg" => "Exam Quesstion Deleted Successfully!",
        ];
        else $msg = [
          "type" => "danger",
          "msg" => "Error while Deleting Exam Question!",
        ];
      } else $msg = [
        "type" => "danger",
        "msg" => "Exam Question Does not Exists!",
      ];
    } else $msg = [
      "type" => "danger",
      "msg" => "Unable to Confirm Exam Question!",
    ];
  }

  // Delete Exam MCQ
  if(isset($_POST['delete_exam_mcq_id'])){
    extract($_POST);
    if($qry=mysqli_query($con, "SELECT * FROM exam_mcqs WHERE id=$delete_exam_mcq_id;")){
      if(mysqli_num_rows($qry) == 1){
        if(mysqli_query($con, "DELETE FROM exam_mcqs WHERE id=$delete_exam_mcq_id;"))
        $msg = [
          "type" => "success",
          "msg" => "Exam MCQ Deleted Successfully!",
        ];
        else $msg = [
          "type" => "danger",
          "msg" => "Error while Deleting Exam MCQ!",
        ];
      } else $msg = [
        "type" => "danger",
        "msg" => "Exam MCQ Does not Exists!",
      ];
    } else $msg = [
      "type" => "danger",
      "msg" => "Unable to Confirm Exam MCQ!",
    ];
  }

  // Fetch Exams
  $exams = [];
  if($qry=mysqli_query($con, "SELECT exams.id, teacher_id, users.fname, users.lname, course_id, subject_id, courses.title as course, subjects.subject as subject, exam_type, start_date, end_date, time_h, time_m, time_s, status, mcq_marks, subjective_marks, (subjective_marks + ((SELECT count(id) FROM exam_mcqs WHERE exam_id=exams.id) * exams.mcq_marks)) AS total_marks FROM exams INNER JOIN users ON exams.teacher_id=users.id INNER JOIN courses ON exams.course_id=courses.id INNER JOIN subjects ON exams.subject_id=subjects.id;"))
  while($exam=mysqli_fetch_assoc($qry))
  $exams[]=$exam;
  else die("Unable to fetch exams from database");

  // Fetch Teachers
  $teachers = [];
  if($qry=mysqli_query($con, "SELECT id, fname, lname FROM users WHERE role='t';"))
  while($teacher=mysqli_fetch_assoc($qry))
  $teachers[]=$teacher;
  else die("Unable to fetch teachers from database");

  // Fetch Courses
  $courses = [];
  if($qry=mysqli_query($con, "SELECT id, title FROM courses;"))
  while($course=mysqli_fetch_assoc($qry))
  $courses[]=$course;
  else die("Unable to fetch courses from database");

  // Fetch Subjects
  $subjects = [];
  if($qry=mysqli_query($con, "SELECT id, subject FROM subjects;"))
  while($subject=mysqli_fetch_assoc($qry))
  $subjects[]=$subject;
  else die("Unable to fetch subject from database");

  include "layouts/dashboard/dashboard_start.php";
?>

<div class="jumbotron">
  <?php
    include "includes/alert.php";
  ?>
  <h1 class="display-4">Exams</h1>
  <p class="lead">
    Manage your exams in followings:
  </p>
  <hr class="my-5">
  <div style="overflow: auto;">
    <table id="data_table" class="data_table table table-striped table-bordered" style="width:100%; min-width: 2000px;">
      <thead>
        <th>#</th>
        <th>Teacher</th>
        <th>Course</th>
        <th>Subject</th>
        <th>Type</th>
        <th>Start - End</th>
        <th>Time</th>
        <th>Marks / MCQ</th>
        <th>Subjective Marks</th>
        <th>Total Marks</th>
        <th>Status</th>
        <th>Actions</th>
      </thead>
      <tbody>
        <?php
          $counter=0;
          foreach($exams as $exam){
            extract($exam);
            $counter++;
            ?>
              <tr>
                <td><?=$counter?></td>
                <td><?=$fname." ".$lname?></td>
                <td><?=$course?></td>
                <td><?=$subject?></td>
                <td><?=$exam_type=='b'?'Both':($exam_type=='a'?'Annual':'Supply')?></td>
                <td><?=$start_date . " => " . $end_date?></td>
                <td><?="${time_h}h ${time_m}m ${time_s}s"?></td>
                <td><?=$mcq_marks?></td>
                <td><?=$subjective_marks?></td>
                <td><?=$total_marks?></td>
                <td><?=$status==0?"Hidden":($status==1?"Active":"Closed")?></td>
                <td>
                  <form action="" method="post" class="d-inline-block">
                    <input type="hidden" name="delete_exam_id" value="<?=$id?>">
                    <button type="submit" class="btn btn-danger">
                      <i class="fa fa-trash"></i>
                    </button>
                  </form>
                  
                  <!-- Update Modal Trigger -->
                  <button type="button" class="btn btn-success" data-bs-toggle="modal" data-bs-target="#editexam_<?=$id?>">
                    <i class="fa fa-edit"></i>
                  </button>

                  <!-- Update Modal -->
                  <form class="modal fade" id="editexam_<?=$id?>" tabindex="-1" aria-hidden="true" action="" method="post">
                    <input type="hidden" name="update_exam_id" value="<?=$id?>">
                    <div class="modal-dialog modal-dialog-centered" style="min-width: 75vw;">
                      <div class="modal-content">
                        <div class="modal-header">
                          <h5 class="modal-title">Update Exam</h5>
                          <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                        </div>
                        <div class="modal-body">
                          <div class="row">
                            <div class="col-md-4">
                              <div class="form-group">
                                <label for="teacher">Teacher</label>
                                <select name="teacher" id="teacher" class="form-control" required>
                                  <?php
                                    foreach($teachers as $teacher){
                                      ?><option value="<?=$teacher['id']?>"<?=$teacher_id==$teacher['id']?" selected":""?>><?=$teacher['fname']." ".$teacher['lname']?></option><?php
                                    }
                                  ?>
                                </select>
                              </div>
                            </div>
                            <div class="col-md-4">
                              <div class="form-group">
                                <label for="course">Course</label>
                                <select name="course" id="course" class="form-control" required>
                                  <?php
                                    foreach($courses as $course){
                                      ?><option value="<?=$course['id']?>"<?=$course_id==$course['id']?" selected":""?>><?=$course['title']?></option><?php
                                    }
                                  ?>
                                </select>
                              </div>
                            </div>
                            <div class="col-md-4">
                              <div class="form-group">
                                <label for="subject">Subject</label>
                                <select name="subject" id="subject" class="form-control" required>
                                  <?php
                                    foreach($subjects as $subject){
                                      ?><option value="<?=$subject['id']?>"<?=$subject_id==$subject['id']?" selected":""?>><?=$subject['subject']?></option><?php
                                    }
                                  ?>
                                </select>
                              </div>
                            </div>
                            <div class="col-md-6">
                              <div class="form-group">
                                <label for="exam_type">Exam Type</label>
                                <select name="exam_type" id="exam_type" class="form-control" required>
                                  <option value="b"<?=$exam_type=='b'?" selected":""?>>Both</option>
                                  <option value="a"<?=$exam_type=='a'?" selected":""?>>Anual</option>
                                  <option value="s"<?=$exam_type=='s'?" selected":""?>>Supply</option>
                                </select>
                              </div>
                            </div>
                            <div class="col-md-3 col-sm-6">
                              <div class="form-group">
                                <label for="start_date">Start</label>
                                <input type="date" class="form-control" name="start_date" id="start_date" value="<?=$start_date?>" required>
                              </div>
                            </div>
                            <div class="col-md-3 col-sm-6">
                              <div class="form-group">
                                <label for="end_date">End</label>
                                <input type="date" class="form-control" name="end_date" id="end_date" value="<?=$end_date?>" required>
                              </div>
                            </div>
                            <div class="col-md-2 col-sm-4">
                              <div class="form-group">
                                <label for="time_h">Hours</label>
                                <input type="number" min="0" max="24" class="form-control" name="time_h" id="time_h" placeholder="Hours" value="<?=$time_h?>" required>
                              </div>
                            </div>
                            <div class="col-md-2 col-sm-4">
                              <div class="form-group">
                                <label for="time_h">Minutes</label>
                                <input type="number" min="0" max="60" class="form-control" name="time_m" id="time_m" placeholder="Minutes" value="<?=$time_m?>" required>
                              </div>
                            </div>
                            <div class="col-md-2 col-sm-4">
                              <div class="form-group">
                                <label for="time_s">Seconds</label>
                                <input type="number" min="0" max="60" class="form-control" name="time_s" id="time_s" placeholder="Seconds" value="<?=$time_s?>" required>
                              </div>
                            </div>
                            <div class="col-md-2 col-sm-4">
                              <div class="form-group">
                                <label for="status">Status</label>
                                <select name="status" id="status" class="form-control" required>
                                  <option value="0"<?=$status==0?" selected":""?>>Hidden</option>
                                  <option value="1"<?=$status==1?" selected":""?>>Active</option>
                                  <option value="2"<?=$status==2?" selected":""?>>Closed</option>
                                </select>
                              </div>
                            </div>
                            <div class="col-md-2 col-sm-4">
                              <div class="form-group">
                                <label for="mcq_marks">Marks / MCQ</label>
                                <input type="number" min="0" class="form-control" name="mcq_marks" id="mcq_marks" placeholder="Marks / MCQ" value="<?=$mcq_marks?>" required>
                              </div>
                            </div>
                            <div class="col-md-2 col-sm-4">
                              <div class="form-group">
                                <label for="subjective_marks">Subjective Marks</label>
                                <input type="number" min="0" class="form-control" name="subjective_marks" id="subjective_marks" placeholder="Subjective Marks" value="<?=$subjective_marks?>" required>
                              </div>
                            </div>
                          </div>
                        </div>
                        <div class="modal-footer">
                          <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                          <button type="submit" class="btn btn-primary">Save changes</button>
                        </div>
                      </div>
                    </div>
                  </form>

                  <!-- Questions Trigger -->
                  <button type="button" class="btn btn-secondary" data-bs-toggle="modal" data-bs-target="#exam_<?=$id?>_questions" title="Questions">
                    <i class="mdi mdi-comment-question-outline"></i>
                  </button>

                  <!-- Question Modal -->
                  <div class="modal fade" id="exam_<?=$id?>_questions" tabindex="-1" aria-hidden="true" action="" method="post">
                    <div class="modal-dialog modal-dialog-centered" style="min-width: 75vw;">
                      <div class="modal-content">
                        <div class="modal-header">
                          <h5 class="modal-title">Exam Questions</h5>
                          <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                        </div>
                        <div class="modal-body">
                          <div class="jumbotron">
                            <h1>Exam Questions:</h1>
                            <p class="lead">
                              Manage your Exam Questions in followings:
                            </p>
                          </div>
                          <hr class="my-3">
                          <table id="data_table2" class="data_table table table-striped table-success table-bordered" style="width:100%">
                            <thead>
                              <th>#</th>
                              <th>Question</th>
                              <th>Actions</th>
                            </thead>
                            <tbody>
                              <?php
                                $counter2 = 0;
                                if($qry = mysqli_query($con, "SELECT * FROM exam_questions WHERE exam_id='$id'"))
                                while($exam_question=mysqli_fetch_assoc($qry)){
                                  $counter2++;
                                  ?>
                                    <tr>
                                      <td><?=$counter2?></td>
                                      <td><?=$exam_question['question']?></td>
                                      <td>
                                        <form action="" method="post" class="d-inline-block">
                                          <input type="hidden" name="delete_exam_question_id" value="<?=$exam_question['id']?>">
                                          <button type="submit" class="btn btn-danger">
                                            <i class="fa fa-trash"></i>
                                          </button>
                                        </form>

                                        <!-- Update Modal Trigger -->
                                        <button type="button" class="btn btn-success" data-bs-toggle="modal" data-bs-target="#editexamquestion_<?=$exam_question['id']?>">
                                          <i class="fa fa-edit"></i>
                                        </button>

                                        <!-- Update Modal -->
                                        <form class="modal fade" id="editexamquestion_<?=$exam_question['id']?>" tabindex="-1" aria-hidden="true" action="" method="post">
                                          <input type="hidden" name="update_exam_question_id" value="<?=$exam_question['id']?>">
                                          <div class="modal-dialog modal-dialog-centered" style="min-width: 50vw">
                                            <div class="modal-content" style="box-shadow: 0 0 20px -10px #000e;">
                                              <div class="modal-header">
                                                <h5 class="modal-title">Update Exam Question</h5>
                                                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                                              </div>
                                              <div class="modal-body">
                                                <div class="form-group">
                                                  <label for="update_exam_<?=$id?>_question_<?=$exam_question['id']?>">Question:</label>
                                                  <input type="text" name="question" id="update_exam_<?=$id?>_question_<?=$exam_question['id']?>" class="form-control" placeholder="Question" value="<?=$exam_question['question']?>" required>
                                                </div>
                                              </div>
                                              <div class="modal-footer">
                                                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                                                <button type="submit" class="btn btn-primary">Save changes</button>
                                              </div>
                                            </div>
                                          </div>
                                        </form>
                                      </td>
                                    </tr>
                                  <?php
                                }
                              ?>
                            </tbody>
                            <tfoot>
                              <th>#</th>
                              <th>Question</th>
                              <th>Actions</th>
                            </tfoot>
                          </table>
                          <hr class="my-4">
                          <div class="jumbotron">
                            <h1 class="display-4">Add New</h1>
                            <p class="lead">
                              Add New Question:
                            </p>
                            <hr>
                            <form action="" method="POST">
                              <input type="hidden" name="add_exam_question" value="true">
                              <input type="hidden" name="exam_id" value="<?=$id?>">
                              <div class="row">
                                <div class="col">
                                  <div class="form-group">
                                    <label for="exam_<?=$id?>_question">Question:</label>
                                    <input type="text" name="question" id="exam_<?=$id?>_question" class="form-control" placeholder="Question" reuqired>
                                  </div>
                                </div>
                                <div class="col-auto">
                                  <div class="form-group">
                                    <label>Submit</label>
                                    <button type="submit" class="btn btn-success form-control">
                                      <i class="fa fa-plus"></i>
                                      Add
                                    </button>
                                  </div>
                                </div>
                              </div>
                            </form>
                          </div>
                        </div>
                        <div class="modal-footer">
                          <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                          <!-- <button type="submit" class="btn btn-primary">Save changes</button> -->
                        </div>
                      </div>
                    </div>
                  </div>

                  <!-- MCQs Trigger -->
                  <button type="button" class="btn btn-secondary" data-bs-toggle="modal" data-bs-target="#exam_<?=$id?>_mcqs" title="MCQs">
                    <i class="mdi mdi-checkbox-multiple-marked-outline"></i>
                  </button>

                  <!-- MCQs Modal -->
                  <div class="modal fade" id="exam_<?=$id?>_mcqs" tabindex="-1" aria-hidden="true" action="" method="post">
                    <div class="modal-dialog modal-dialog-centered" style="min-width: 75vw;">
                      <div class="modal-content">
                        <div class="modal-header">
                          <h5 class="modal-title">Exam MCQs</h5>
                          <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                        </div>
                        <div class="modal-body">
                          <div class="jumbotron">
                            <h1>Exam MCQs:</h1>
                            <p class="lead">
                              Manage your Exam MCQs in followings:
                            </p>
                          </div>
                          <hr class="my-3">
                          <table id="data_table3" class="data_table table table-striped table-success table-bordered" style="width:100%">
                            <thead>
                              <th>#</th>
                              <th>Question</th>
                              <th>A</th>
                              <th>B</th>
                              <th>C</th>
                              <th>D</th>
                              <th>Correct</th>
                              <th>Actions</th>
                            </thead>
                            <tbody>
                              <?php
                                $counter2 = 0;
                                if($qry = mysqli_query($con, "SELECT * FROM exam_mcqs WHERE exam_id='$id'"))
                                while($exam_mcq=mysqli_fetch_assoc($qry)){
                                  $counter2++;
                                  ?>
                                    <tr>
                                      <td><?=$counter2?></td>
                                      <td><?=$exam_mcq['question']?></td>
                                      <td><?=$exam_mcq['option_a']?></td>
                                      <td><?=$exam_mcq['option_b']?></td>
                                      <td><?=$exam_mcq['option_c']?></td>
                                      <td><?=$exam_mcq['option_d']?></td>
                                      <td><?=strtoupper($exam_mcq['correct'])?></td>
                                      <td>
                                        <form action="" method="post" class="d-inline-block">
                                          <input type="hidden" name="delete_exam_mcq_id" value="<?=$exam_mcq['id']?>">
                                          <button type="submit" class="btn btn-danger">
                                            <i class="fa fa-trash"></i>
                                          </button>
                                        </form>

                                        <!-- Update Modal Trigger -->
                                        <button type="button" class="btn btn-success" data-bs-toggle="modal" data-bs-target="#editexammcq_<?=$exam_mcq['id']?>">
                                          <i class="fa fa-edit"></i>
                                        </button>

                                        <!-- Update Modal -->
                                        <form class="modal fade" id="editexammcq_<?=$exam_mcq['id']?>" tabindex="-1" aria-hidden="true" action="" method="post">
                                          <input type="hidden" name="update_exam_mcq_id" value="<?=$exam_mcq['id']?>">
                                          <div class="modal-dialog modal-dialog-centered" style="min-width: 50vw">
                                            <div class="modal-content" style="box-shadow: 0 0 20px -10px #000e;">
                                              <div class="modal-header">
                                                <h5 class="modal-title">Update Exam MCQ</h5>
                                                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                                              </div>
                                              <div class="modal-body">
                                                <div class="row">
                                                  <div class="col-12">
                                                    <div class="form-group">
                                                      <label for="exam_<?=$id?>_mcq_<?=$exam_mcq['id']?>_question">Question:</label>
                                                      <input type="text" name="question" id="exam_<?=$id?>_mcq_<?=$exam_mcq['id']?>_question" class="form-control" placeholder="Question" reuqired value="<?=$exam_mcq['question']?>">
                                                    </div>
                                                  </div>
                                                  <div class="col-6">
                                                    <div class="form-group">
                                                      <label for="exam_<?=$id?>_mcq_<?=$exam_mcq['id']?>_question_option_a">Option A:</label>
                                                      <input type="text" name="option_a" id="exam_<?=$id?>_mcq_<?=$exam_mcq['id']?>_question_option_a" class="form-control" placeholder="Option A" reuqired value="<?=$exam_mcq['option_a']?>">
                                                    </div>
                                                  </div>
                                                  <div class="col-6">
                                                    <div class="form-group">
                                                      <label for="exam_<?=$id?>_mcq_<?=$exam_mcq['id']?>_question_option_b">Option B:</label>
                                                      <input type="text" name="option_b" id="exam_<?=$id?>_mcq_<?=$exam_mcq['id']?>_question_option_b" class="form-control" placeholder="Option B" reuqired value="<?=$exam_mcq['option_b']?>">
                                                    </div>
                                                  </div>
                                                  <div class="col-6">
                                                    <div class="form-group">
                                                      <label for="exam_<?=$id?>_mcq_<?=$exam_mcq['id']?>_question_option_c">Option C:</label>
                                                      <input type="text" name="option_c" id="exam_<?=$id?>_mcq_<?=$exam_mcq['id']?>_question_option_c" class="form-control" placeholder="Option C" reuqired value="<?=$exam_mcq['option_c']?>">
                                                    </div>
                                                  </div>
                                                  <div class="col-6">
                                                    <div class="form-group">
                                                      <label for="exam_<?=$id?>_mcq_<?=$exam_mcq['id']?>_question_option_d">Option D:</label>
                                                      <input type="text" name="option_d" id="exam_<?=$id?>_mcq_<?=$exam_mcq['id']?>_question_option_d" class="form-control" placeholder="Option D" reuqired value="<?=$exam_mcq['option_d']?>">
                                                    </div>
                                                  </div>
                                                  <div class="col-12">
                                                    <div class="form-group row" style="align-items: center;">
                                                      <div class="col-auto">
                                                        <label for="exam_<?=$id?>_mcq_<?=$exam_mcq['id']?>_question_correct">Correct Option:</label>
                                                      </div>
                                                      <div class="col">
                                                        <select name="correct" id="exam_<?=$id?>_mcq_<?=$exam_mcq['id']?>_question_correct" class="form-control" required>
                                                          <option value="a"<?=$exam_mcq['correct']=='a'?" selected":""?>>A</option>
                                                          <option value="b"<?=$exam_mcq['correct']=='b'?" selected":""?>>B</option>
                                                          <option value="c"<?=$exam_mcq['correct']=='c'?" selected":""?>>C</option>
                                                          <option value="d"<?=$exam_mcq['correct']=='d'?" selected":""?>>D</option>
                                                        </select>
                                                      </div>
                                                    </div>
                                                  </div>
                                                </div>
                                              </div>
                                              <div class="modal-footer">
                                                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                                                <button type="submit" class="btn btn-primary">Save changes</button>
                                              </div>
                                            </div>
                                          </div>
                                        </form>
                                      </td>
                                    </tr>
                                  <?php
                                }
                              ?>
                            </tbody>
                            <tfoot>
                              <th>#</th>
                              <th>Question</th>
                              <th>A</th>
                              <th>B</th>
                              <th>C</th>
                              <th>D</th>
                              <th>Correct</th>
                              <th>Actions</th>
                            </tfoot>
                          </table>
                          <hr class="my-4">
                          <div class="jumbotron">
                            <h1 class="display-4">Add New</h1>
                            <p class="lead">
                              Add New MCQ:
                            </p>
                            <hr>
                            <form action="" method="POST">
                              <input type="hidden" name="add_exam_mcq" value="true">
                              <input type="hidden" name="exam_id" value="<?=$id?>">
                              <div class="row">
                                <div class="col-12">
                                  <div class="form-group">
                                    <label for="exam_<?=$id?>_question">Question:</label>
                                    <input type="text" name="question" id="exam_<?=$id?>_question" class="form-control" placeholder="Question" reuqired>
                                  </div>
                                </div>
                                <div class="col-6">
                                  <div class="form-group">
                                    <label for="exam_<?=$id?>_question_option_a">Option A:</label>
                                    <input type="text" name="option_a" id="exam_<?=$id?>_question_option_a" class="form-control" placeholder="Option A" reuqired>
                                  </div>
                                </div>
                                <div class="col-6">
                                  <div class="form-group">
                                    <label for="exam_<?=$id?>_question_option_b">Option B:</label>
                                    <input type="text" name="option_b" id="exam_<?=$id?>_question_option_b" class="form-control" placeholder="Option B" reuqired>
                                  </div>
                                </div>
                                <div class="col-6">
                                  <div class="form-group">
                                    <label for="exam_<?=$id?>_question_option_c">Option C:</label>
                                    <input type="text" name="option_c" id="exam_<?=$id?>_question_option_c" class="form-control" placeholder="Option C" reuqired>
                                  </div>
                                </div>
                                <div class="col-6">
                                  <div class="form-group">
                                    <label for="exam_<?=$id?>_question_option_d">Option D:</label>
                                    <input type="text" name="option_d" id="exam_<?=$id?>_question_option_d" class="form-control" placeholder="Option D" reuqired>
                                  </div>
                                </div>
                                <div class="col-md-6">
                                  <div class="form-group">
                                    <label for="exam_<?=$id?>_question_correct">Correct Option:</label>
                                    <select name="correct" id="exam_<?=$id?>_question_correct" class="form-control" required>
                                      <option value="a" selected>A</option>
                                      <option value="b">B</option>
                                      <option value="c">C</option>
                                      <option value="d">D</option>
                                    </select>
                                  </div>
                                </div>
                                <div class="col-md-6">
                                  <div class="form-group">
                                    <label>Submit</label>
                                    <button type="submit" class="btn btn-success form-control">
                                      <i class="fa fa-plus"></i>
                                      Add
                                    </button>
                                  </div>
                                </div>
                              </div>
                            </form>
                          </div>
                        </div>
                        <div class="modal-footer">
                          <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                        </div>
                      </div>
                    </div>
                  </div>
                </td>
              </tr>
            <?php
          }
        ?>
      </tbody>
      <tfoot>
        <th>#</th>
        <th>Teacher</th>
        <th>Course</th>
        <th>Subject</th>
        <th>Type</th>
        <th>Start - End</th>
        <th>Time</th>
        <th>Marks / MCQ</th>
        <th>Subjective Marks</th>
        <th>Total Marks</th>
        <th>Status</th>
        <th>Actions</th>
      </tfoot>
    </table>
  </div>
</div>

<div class="jumbotron">
  <h1 class="display-4">Create new Exam</h1>
  <p class="lead">
    Create New Exam
  </p>
  <hr>
  <form action="" method="post">
    <input type="hidden" name="add_exam" value="true">
    <div class="row">
      <div class="col-md-4">
        <div class="form-group">
          <label for="teacher">Teacher</label>
          <select name="teacher" id="teacher" class="form-control" required>
            <option value="" selected class="d-none">Select Teacher</option>
            <?php
              foreach($teachers as $teacher){
                ?><option value="<?=$teacher['id']?>"><?=$teacher['fname']." ".$teacher['lname']?></option><?php
              }
            ?>
          </select>
        </div>
      </div>
      <div class="col-md-4">
        <div class="form-group">
          <label for="course">Course</label>
          <select name="course" id="course" class="form-control" required>
            <option value="" selected class="d-none">Select Course</option>
            <?php
              foreach($courses as $course){
                ?><option value="<?=$course['id']?>"><?=$course['title']?></option><?php
              }
            ?>
          </select>
        </div>
      </div>
      <div class="col-md-4">
        <div class="form-group">
          <label for="subject">Subject</label>
          <select name="subject" id="subject" class="form-control" required>
            <option value="" selected class="d-none">Select Subject</option>
            <?php
              foreach($subjects as $subject){
                ?><option value="<?=$subject['id']?>"><?=$subject['subject']?></option><?php
              }
            ?>
          </select>
        </div>
      </div>
      <div class="col-md-6">
        <div class="form-group">
          <label for="exam_type">Exam Type</label>
          <select name="exam_type" id="exam_type" class="form-control" required>
            <option value="b" selected>Both</option>
            <option value="a">Anual</option>
            <option value="s">Supply</option>
          </select>
        </div>
      </div>
      <div class="col-md-3 col-sm-6">
        <div class="form-group">
          <label for="start_date">Start</label>
          <input type="date" class="form-control" name="start_date" id="start_date" required>
        </div>
      </div>
      <div class="col-md-3 col-sm-6">
        <div class="form-group">
          <label for="end_date">End</label>
          <input type="date" class="form-control" name="end_date" id="end_date" required>
        </div>
      </div>
      <div class="col-md-2 col-sm-4">
        <div class="form-group">
          <label for="time_h">Hours</label>
          <input type="number" min="0" max="24" value="1" class="form-control" name="time_h" id="time_h" placeholder="Hours" required>
        </div>
      </div>
      <div class="col-md-2 col-sm-4">
        <div class="form-group">
          <label for="time_h">Minutes</label>
          <input type="number" min="0" max="60" value="30" class="form-control" name="time_m" id="time_m" placeholder="Minutes" required>
        </div>
      </div>
      <div class="col-md-2 col-sm-4">
        <div class="form-group">
          <label for="time_s">Seconds</label>
          <input type="number" min="0" max="60" value="0" class="form-control" name="time_s" id="time_s" placeholder="Seconds" required>
        </div>
      </div>
      <div class="col-md-2 col-sm-4">
        <div class="form-group">
          <label for="status">Status</label>
          <select name="status" id="status" class="form-control" required>
            <option value="0" selected>Hidden</option>
            <option value="1">Active</option>
            <option value="2">Closed</option>
          </select>
        </div>
      </div>
      <div class="col-md-2 col-sm-4">
        <div class="form-group">
          <label for="mcq_marks">Marks / MCQ</label>
          <input type="number" min="0" value="1" class="form-control" name="mcq_marks" id="mcq_marks" placeholder="Marks / MCQ" required>
        </div>
      </div>
      <div class="col-md-2 col-sm-4">
        <div class="form-group">
          <label for="subjective_marks">Subjective Marks</label>
          <input type="number" min="0" value="1" class="form-control" name="subjective_marks" id="subjective_marks" placeholder="Subjective marks" required>
        </div>
      </div>
    </div>
    <br>
    <button type="submit" class="btn btn-success">
      <i class="fa fa-exam-plus"></i>
      Add
    </button>
    <button type="reset" class="btn btn-secondary">Clear</button>
  </form>
</div>

<?php
  include "layouts/dashboard/dashboard_end.php";
?>