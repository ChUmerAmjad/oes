<?php
  if(!isset($con)) require "includes/con.php";
  if(!isset($user)) require "includes/auth.php";

  if(!in_array($user['role'], ['a', 't']))
  header('location: login.php');

  // Add Subject
  if(isset($_POST['add_subject'])){
    extract($_POST);
    if($qry=mysqli_query($con, "SELECT * FROM subjects WHERE subject = '$subject';")){
      if(mysqli_num_rows($qry) == 0){
        if(mysqli_query($con, "INSERT INTO subjects(subject) VALUES ('$subject');"))
        $msg = [
          "type" => "success",
          "msg" => "Subject Inserted Successfully!",
        ];
        else $msg = [
          "type" => "danger",
          "msg" => "Error while Inserting subject!",
        ];
      } else {
        $msg = [
          "type" => "danger",
          "msg" => "Subject Already Added!",
        ];
      }
    }
  }

  // Update subject
  if(isset($_POST['update_subject_id'])){
    extract($_POST);
    if($qry=mysqli_query($con, "SELECT * FROM subjects WHERE id=$update_subject_id;")){
      if(mysqli_num_rows($qry) == 1){
        if($qry=mysqli_query($con, "SELECT * FROM subjects WHERE subject='$subject' AND id!=$update_subject_id;")){
          if(mysqli_num_rows($qry) == 0){
            if(mysqli_query($con, "UPDATE subjects SET subject='$subject' WHERE id=$update_subject_id;"))
            $msg = [
              "type" => "success",
              "msg" => "Subject Updated Successfully!",
            ];
            else $msg = [
              "type" => "danger",
              "msg" => "Error while Updating subject!",
            ];
          } else $msg = [
            "type" => "danger",
            "msg" => "Subject Name Already Exists!",
          ];
        } else $msg = [
          "type" => "danger",
          "msg" => "Unable to Confirm Subject Name!",
        ];
      } else $msg = [
        "type" => "danger",
        "msg" => "Subject Does not Exists!",
      ];
    } else $msg = [
      "type" => "danger",
      "msg" => "Unable to Confirm Subject!",
    ];
  }

  // Delete Subject
  if(isset($_POST['delete_subject_id'])){
    extract($_POST);
    if($qry=mysqli_query($con, "SELECT * FROM subjects WHERE id=$delete_subject_id;")){
      if(mysqli_num_rows($qry) == 1){
        if(mysqli_query($con, "DELETE FROM subjects WHERE Id=$delete_subject_id;"))
        $msg = [
          "type" => "success",
          "msg" => "Subject Deleted Successfully!",
        ];
        else $msg = [
          "type" => "danger",
          "msg" => "Error while Deleting subject!",
        ];
      } else $msg = [
        "type" => "danger",
        "msg" => "Subject Does not Exists!",
      ];
    } else $msg = [
      "type" => "danger",
      "msg" => "Unable to Confirm Subject!",
    ];
  }


  // Fetch Subjects
  $subjects = [];
  if($qry=mysqli_query($con, "SELECT * FROM subjects;"))
  while($subject=mysqli_fetch_assoc($qry))
  $subjects[]=$subject;
  else die("Unable to fetch subjects from database");

  include "layouts/dashboard/dashboard_start.php";
?>

<div class="jumbotron">
  <?php
    include "includes/alert.php";
  ?>
  <h1 class="display-4">Subjects</h1>
  <p class="lead">
    Manage your database subjects in followings:
  </p>
  <hr class="my-5">
  <table id="data_table" class="data_table table table-striped table-bordered" style="width:100%">
    <thead>
      <th>#</th>
      <th>Subject</th>
      <th>Actions</th>
    </thead>
    <tbody>
      <?php
        $counter=0;
        foreach($subjects as $subject){
          extract($subject);
          $counter++;
          ?>
            <tr>
              <td><?=$counter?></td>
              <td><?=$subject?></td>
              <td>
                <form action="" method="post" class="d-inline-block">
                  <input type="hidden" name="delete_subject_id" value="<?=$id?>">
                  <button type="submit" class="btn btn-danger">
                    <i class="fa fa-trash"></i>
                  </button>
                </form>
                
                <!-- Update Modal Trigger -->
                <button type="button" class="btn btn-success" data-bs-toggle="modal" data-bs-target="#edit_subject_<?=$id?>">
                  <i class="fa fa-edit"></i>
                </button>
                <!-- Update Modal -->
                <form class="modal fade" id="edit_subject_<?=$id?>" tabindex="-1" aria-hidden="true" action="" method="post">
                  <input type="hidden" name="update_subject_id" value="<?=$id?>">
                  <div class="modal-dialog modal-dialog-centered">
                    <div class="modal-content">
                      <div class="modal-header">
                        <h5 class="modal-title">Update Subject</h5>
                        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                      </div>
                      <div class="modal-body">
                        <div class="row">
                          <div class="col-md-12">
                            <div class="form-group">
                              <label for="update_<?=$id?>_subject">Subject Name</label>
                              <input type="text" class="form-control" name="subject" id="update_<?=$id?>_subject" placeholder="Subject Name" value="<?=$subject?>" required>
                            </div>
                          </div>
                        </div>
                      </div>
                      <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                        <button type="submit" class="btn btn-primary">Save changes</button>
                      </div>
                    </div>
                  </div>
                </form>
              </td>
            </tr>
          <?php
        }
      ?>
    </tbody>
    <tfoot>
      <th>#</th>
      <th>Subject</th>
      <th>Actions</th>
    </tfoot>
  </table>
</div>

<div class="jumbotron">
  <h1 class="display-4">Add new Subject</h1>
  <p class="lead">
    Create New Subject
  </p>
  <hr>
  <form action="" method="post" class="d-block">
    <input type="hidden" name="add_subject" value="true">
    <div class="row">
      <div class="col-md-12">
        <div class="form-group">
          <label for="subject">Subject Name</label>
          <input type="text" class="form-control" name="subject" id="subject" placeholder="Subject Name" required>
        </div>
      </div>
    </div>
    <br>
    <button type="submit" class="btn btn-success">
      <i class="fa fa-book"></i>
      Create
    </button>
    <button type="reset" class="btn btn-secondary">Clear</button>
  </form>
</div>

<?php
  include "layouts/dashboard/dashboard_end.php";
?>