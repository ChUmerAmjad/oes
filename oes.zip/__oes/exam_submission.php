<?php
  if(!isset($con)) require "includes/con.php";
  if(!isset($user)) require "includes/auth.php";

  if(in_array($user['role'], ['a', 't']))
  header('location: dashboard.php');
  elseif($user['role']!='s')
  header('location: login.php');

  // Redirect Invalid Data-User
  if(!isset($_POST['exam_id']))
  header('location: index.php');

  // variables
  $exam_id = $_POST['exam_id'];
  $exam_type = $_POST['type'];
  $_exam_type = $_POST['type'];

  // Upload File
  if(isset($_FILES['file']))
  if(move_uploaded_file($_FILES['file']["tmp_name"], $src="uploads/".time().rand(100000, 999999)."_".$_FILES['file']['name']))

  global $already_started;
  $already_started = false;

  // Confirming Already Submission
  if($qry=mysqli_query($con, $sql="SELECT count(id) FROM exams_submissions WHERE exam_id='$exam_id' AND type='$exam_type' AND student_id='".$user['id']."'")){
    if(mysqli_fetch_row($qry)[0]>0)
    $already_started = true;
  } else die("Unable to Confirm Exam Submission");

  // Redirect Invalid Data-User
  if(!$already_started && !isset($_POST['type']))
  header('location: index.php');

  // Create Exam Submission if not started yet
  if(!$already_started){
    if(!mysqli_query($con, "INSERT INTO exams_submissions(exam_id, type, student_id) VALUES ('$exam_id', '$exam_type', '".$user['id']."');"))
    die("Unable to Create Exam Submission Instance!");
  }

  // Fetch Exam Submission
  $exam_submission = null;
  if($qry=mysqli_query($con, "SELECT exams_submissions.id, type, marks, submission_status, grading_status, date, time, lm_date, lm_time, submission_comment, users.fname, users.lname, subject, exam_type, start_date, end_date, time_h, time_m, time_s, status, subjective_marks, mcq_marks, (subjective_marks + ((SELECT count(id) FROM exam_mcqs WHERE exam_id=exams.id) * exams.mcq_marks)) AS total_marks FROM exams_submissions INNER JOIN exams ON exam_id=exams.id INNER JOIN subjects on subject_id=subjects.id INNER JOIN courses ON course_id=courses.id INNER JOIN users ON teacher_id=users.id WHERE exam_id='$exam_id' AND type='$exam_type' AND student_id='".$user['id']."';")){
    if(mysqli_num_rows($qry)==0) die("Exam Submissoin Not Found!");
    $exam_submission = mysqli_fetch_assoc($qry);
  } else die("Unable to fetch exam_submission");
  extract($exam_submission);

  // Fetching Submitted MCQs
  $submitted_mcqs = [];
  if($qry=mysqli_query($con, $sql="SELECT exam_submission_mcqs.id, question_id, selected_option, correct FROM exam_submission_mcqs INNER JOIN exam_mcqs ON question_id=exam_mcqs.id WHERE exam_submission_id='".$exam_submission['id']."';"))
  while($mcq=mysqli_fetch_assoc($qry))
  $submitted_mcqs[]=$mcq;
  else die("Unable to fetch submitted MCQs");

  // Fetching Exam Questions
  $exam_questions = [];
  if($qry=mysqli_query($con, "SELECT id, question FROM exam_questions WHERE exam_id='$exam_id'"))
  while($question=mysqli_fetch_assoc($qry))
  $exam_questions[]=$question;
  else die("unable to fetch Exam Questions!");

  // Fetching Exam MCQs
  $exam_mcqs = [];
  if($qry=mysqli_query($con, "SELECT id, question, option_a, option_b, option_c, option_d, correct FROM exam_mcqs WHERE exam_id='$exam_id'"))
  while($mcq=mysqli_fetch_assoc($qry))
  $exam_mcqs[]=$mcq;
  else die("unable to fetch Exam MCQs!");

  // Upload File Save
  if(isset($_FILES['file']))
  mysqli_query($con, "INSERT INTO exam_submission_files (exam_submission_id, file_src) VALUES ('".$exam_submission['id']."', '$src');")
  && mysqli_query($con, "UPDATE exam_submissions SET lm_date=CURRENT_DATE, lm_time=CURRENT_TIME where id='".$exam_submission['id']."';");

  // Delete File
  if(isset($_POST['delete_file_id']))
  mysqli_query($con, "DELETE FROM exam_submission_files WHERE id='".$_POST['delete_file_id']."';");
  
  // Fetch Submission Files
  $exam_files = [];
  if($qry=mysqli_query($con, "SELECT id, file_src FROM exam_submission_files WHERE exam_submission_id='".$exam_submission['id']."';"))
  while($file=mysqli_fetch_assoc($qry))
  $exam_files[]=$file;
  else die("unable to fetch Exam Files!");

  require "layouts/student/layout_start.php";
?>

<script src="assets/js/exam.js"></script>
<style>
  .eq-link.bg-success:not(.active){
    color: #fff;
  }
  .eq-link + .eq-link{
    margin-top: 5px;
  }
</style>

<div class="row p-5">
  <div class="col-12">
    <h1 class="display-4">Exam Submission:</h1>
    <p class="lead">
      Your Exam has started. Submit Your Exam in Followings:
    </p>
    <hr class="my-4">
    <div class="row">
      <table class="table table-dark table-striped">
        <tbody>
          <tr>
            <th>Teacher::</th>
            <td>
              <?=$fname." ".$lname?>
            </td>
          </tr>
          <tr>
            <th>Subject::</th>
            <td>
              <?=$subject?>
            </td>
          </tr>
          <tr>
            <th>Exam Type::</th>
            <td>
              <?=$type=='b'?'Both (Anual & Supply)':($exam_type=='a'?'Annual':'Supply')?>
            </td>
          </tr>
          <tr>
            <th>Total Marks:</th>
            <td>
              <?=$total_marks?>
            </td>
          </tr>
          <tr>
            <th>Subjective Marks:</th>
            <td>
              <?=$subjective_marks?>
            </td>
          </tr>
          <tr>
            <th>MCQs Marks:</th>
            <td>
              <?=$total_marks-$subjective_marks?>
            </td>
          </tr>
          <tr>
            <th>Started At:</th>
            <td>
              <?=$date." - ".$time?>
            </td>
          </tr>
          <tr>
            <th>Due Date:</th>
            <td>
              <?=$end_date?>
            </td>
          </tr>
          <tr>
            <th>Duration::</th>
            <td>
              <?="${time_h}h ${time_m}m ${time_s}s"?>
            </td>
          </tr>
          <?php
            if($exam_submission['submission_status']==0){
              ?>
                <tr>
                  <th>Remaining::</th>
                  <td>
                    <span class="counter-update">Loading...</span>
                  </td>
                </tr>
              <?php
            }
          ?>
          <tr>
            <th>Submission Status:</th>
            <td>
              <?=$submission_status==0?"<span class='text-danger'>Not Submitted<span>":"<span class='text-success'>Submitted</span>"?>
            </td>
          </tr>
        </tbody>
      </table>
    </div>
    <div class="row my-5">
      <div class="col-12">
        <h1>Questions:</h1>
        <p class="lead">
          Subjective Questions are as follow:
        </p>
        <hr class="my-3">
      </div>
      <div class="col-12">
        <table class="table table-light table-striped">
          <thead>
            <th>#</th>
            <th>Question</th>
          </thead>
          <tbody>
            <?php
              $count=0;
              foreach($exam_questions as $question){
                $count++;
                ?>
                  <tr>
                    <td><?=$count?></td>
                    <td><?=$question['question']?></td>
                  </tr>
                <?php
              }
            ?>
          </tbody>
        </table>
      </div>
    </div>
    <div class="row mb-5">
      <div class="col-12">
        <h3>Files</h3>
        <p class="lead text-muted">
          Manage Your Files in Followings
        </p>
        <table class="table table-light table-striped table-hover">
          <thead>
            <th>#</th>
            <th>File</th>
            <?=$exam_submission['submission_status']==0?"<th>Action</th>":""?>
          </thead>
          <tbody>
            <?php
              $count=0;
              if(count($exam_files)>0)
              foreach($exam_files as $file){
                $count++;
                ?>
                  <tr>
                    <td><?=$count?></td>
                    <td>
                      <a href="<?=$file['file_src']?>" class="btn btn-primary">View / Download</a>
                    </td>
                    <?php
                      if($exam_submission['submission_status']==0){
                        ?>
                          <td>
                            <form action="" method="post">
                              <input type="hidden" name="exam_id" value="<?=$exam_id?>">
                              <input type="hidden" name="type" value="<?=$_exam_type?>">
                              <input type="hidden" name="delete_file_id" value="<?=$file['id']?>">
                              <button class="btn btn-danger">&times; Delete</button>
                            </form>
                          </td>
                        <?php
                      }
                    ?>
                  </tr>
                <?php
              } else {
                ?>
                  <tr>
                    <td colspan="3">
                      <span class="text-danger">No File Uploaded!</span>
                    </td>
                  </tr>
                <?php
              }
            ?>
          </tbody>
        </table>
        <?php
          if($exam_submission['submission_status']==0){
            ?>
              <form action="" method="post" enctype="multipart/form-data">
                <input type="hidden" name="exam_id" value="<?=$exam_id?>">
                <input type="hidden" name="type" value="<?=$_exam_type?>">
                <div class="row pt-5">
                  <div class="col-12">
                    <h3>Upload File</h3>
                  </div>
                  <div class="col">
                    <div class="form-group">
                      <label for="file">Upload File:</label>
                      <input type="file" name="file" id="file" class="form-control">
                    </div>
                  </div>
                  <div class="col-auto">
                    <div class="form-group">
                      <label>Submit:</label>
                      <button class="form-control btn btn-success">&DoubleUpArrow; Upload</button>
                    </div>
                  </div>
                </div>
              </form>
            <?php
          }
        ?>
        <hr>
      </div>
    </div>
    <div class="row my-5">
      <div class="col-12">
        <h1>MCQs:</h1>
        <p class="lead">
          Solve your MCQs in followings:
        </p>
        <hr class="my-3">
      </div>
      <div class="col-12">
        <div class="row border">
          <div class="nav flex-column nav-pills col-3" id="v-pills-tab" role="tablist" aria-orientation="vertical">
            <?php
              function is_submitted_mcq($mcq_id){
                global $submitted_mcqs;
                foreach($submitted_mcqs as $mcq)
                if($mcq_id==$mcq['question_id'])
                return $mcq;
                return false;
              }
              $count=0;
              foreach($exam_mcqs as $mcq){
                $count++;
                ?>
                  <a class="nav-link<?=$count==1?" active":""?><?=is_submitted_mcq($mcq['id'])?" bg-success":""?> eq-link" id="mcq-<?=$mcq['id']?>" data-toggle="pill" href="#mcq-<?=$mcq['id']?>-display" role="tab">Question <?=$count?></a>
                <?php
              }
            ?>
          </div>
          <div class="tab-content col-9" id="v-pills-tabContent">
            <?php
              $count=0;
              foreach($exam_mcqs as $mcq){
                $count++;
                ?>
                  <div class="tab-pane fade<?=$count==1?" show active":""?>" id="mcq-<?=$mcq['id']?>-display" role="tabpanel">
                    <div class="bg-light m-3 p-4 border rounded">
                      <h3 class="m-0">Q<?=$count?>: <?=$mcq['question']?></h3>
                      <div class="row m-3">
                        <div class="col-md-6 p-1">
                          <input type="radio" value="a" name="mcq_<?=$mcq['id']?>_question" id="mcq_<?=$mcq['id']?>_option_a"<?=($sub=is_submitted_mcq($mcq['id']))?" disabled".($sub['selected_option']=='a'?" checked":""):""?>>
                          <label for="mcq_<?=$mcq['id']?>_option_a"<?=$exam_submission['status']==2?($mcq['correct']=='a'?" class='text-success'":""):""?>><?=$mcq['option_a']?></label>
                        </div>
                        <div class="col-md-6 p-1">
                          <input type="radio" value="b" name="mcq_<?=$mcq['id']?>_question" id="mcq_<?=$mcq['id']?>_option_b"<?=($sub=is_submitted_mcq($mcq['id']))?" disabled".($sub['selected_option']=='b'?" checked":""):""?>>
                          <label for="mcq_<?=$mcq['id']?>_option_b"<?=$exam_submission['status']==2?($mcq['correct']=='b'?" class='text-success'":""):""?>><?=$mcq['option_b']?></label>
                        </div>
                        <div class="col-md-6 p-1">
                          <input type="radio" value="c" name="mcq_<?=$mcq['id']?>_question" id="mcq_<?=$mcq['id']?>_option_c"<?=($sub=is_submitted_mcq($mcq['id']))?" disabled".($sub['selected_option']=='c'?" checked":""):""?>>
                          <label for="mcq_<?=$mcq['id']?>_option_c"<?=$exam_submission['status']==2?($mcq['correct']=='c'?" class='text-success'":""):""?>><?=$mcq['option_c']?></label>
                        </div>
                        <div class="col-md-6 p-1">
                          <input type="radio" value="d" name="mcq_<?=$mcq['id']?>_question" id="mcq_<?=$mcq['id']?>_option_d"<?=($sub=is_submitted_mcq($mcq['id']))?" disabled".($sub['selected_option']=='d'?" checked":""):""?>>
                          <label for="mcq_<?=$mcq['id']?>_option_d"<?=$exam_submission['status']==2?($mcq['correct']=='d'?" class='text-success'":""):""?>><?=$mcq['option_d']?></label>
                        </div>
                        <?php
                          if($exam_submission['submission_status']==0){
                            ?>
                              <div class="col-12 text-right">
                                <button type="button" class="btn btn-success"<?=is_submitted_mcq($mcq['id'])?" disabled":""?> onclick="submit_mcq(this, <?=$exam_submission['id']?>, <?=$mcq['id']?>);">Submit</button>
                              </div>
                            <?php
                          }
                        ?>
                      </div>
                    </div>
                  </div>
                <?php
              }
            ?>
          </div>
        </div>
      </div>
    </div>
    <div class="row my-5">
      <div class="col-12">
        <h1>Submit Exam:</h1>
        <p class="lead">
          Click Following button to submit exam:
        </p>
        <form action="submit_exam.php" method="post">
          <input type="hidden" name="submition_id" value="<?=$exam_submission['id']?>">
          <div class="form-grouop">
            <textarea name="submission_comment" id="submission_comment" rows="3" class="form-control" placeholder="Submission Comment" style="resize: none;"<?=$exam_submission['submission_status']==0?"":" disabled"?>><?=$exam_submission['submission_comment']?></textarea>
          </div>
          <br>
          <button type="submit" id="submit_exam_trigger" class="btn btn-success btn-lg"<?=$exam_submission['submission_status']==0?"":" disabled"?>>Submit Exam</button>
        </form>
      </div>
    </div>
  </div>
</div>
<?php
  if($exam_submission['submission_status']==0){
    ?>
      <script>
        var start = new Date(Date.parse('<?="$date $time"?>'));
        var duration_hours = <?=$time_h?>;
        var duration_minutes = <?=$time_m?>;
        var duration_seconds = <?=$time_s?>;

        initializeCounter(start, duration_hours, duration_minutes, duration_seconds);
      </script>
    <?php
  }
?>

<?php
  require "layouts/student/layout_end.php";
?>