<?php
  if(!isset($con)) require "includes/con.php";
  if(!isset($user)) require "includes/auth.php";

  if(!in_array($user['role'], ['a', 't']))
  header('location: login.php');

  // Add Student-Course
  if(isset($_POST['add_student_course'])){
    extract($_POST);
    if($qry=mysqli_query($con, "SELECT * FROM student_courses WHERE student_id='$student' AND course_id='$course';")){
      if(mysqli_num_rows($qry) == 0){
        if(mysqli_query($con, "INSERT INTO student_courses(student_id, course_id) VALUES ('$student', '$course');"))
        $msg = [
          "type" => "success",
          "msg" => "Student-Course Inserted Successfully!",
        ];
        else $msg = [
          "type" => "danger",
          "msg" => "Error while Inserting Student-Course!",
        ];
      } else {
        $msg = [
          "type" => "danger",
          "msg" => "Student Already Enrolled in this Course!",
        ];
      }
    }
  }

  // Update student_course
  if(isset($_POST['update_student_course_id'])){
    extract($_POST);
    if($qry=mysqli_query($con, "SELECT * FROM student_courses WHERE id=$update_student_course_id;")){
      if(mysqli_num_rows($qry) == 1){
        if($qry=mysqli_query($con, "SELECT * FROM student_courses WHERE student_id='$student' AND course_id='$course' AND id!=$update_student_course_id;")){
          if(mysqli_num_rows($qry) == 0){
            if(mysqli_query($con, "UPDATE student_courses SET student_id='$student', course_id='$course' WHERE id=$update_student_course_id;"))
            $msg = [
              "type" => "success",
              "msg" => "Student-Course Updated Successfully!",
            ];
            else $msg = [
              "type" => "danger",
              "msg" => "Error while Updating Student-Course!",
            ];
          } else $msg = [
            "type" => "danger",
            "msg" => "Student Already Enrolled in this Course!",
          ];
        } else $msg = [
          "type" => "danger",
          "msg" => "Unable to Confirm Student-Course!",
        ];
      } else $msg = [
        "type" => "danger",
        "msg" => "Student-Course Does not Exists!",
      ];
    } else $msg = [
      "type" => "danger",
      "msg" => "Unable to Confirm Student-Course!",
    ];
  }

  // Delete Student-Course
  if(isset($_POST['delete_student_course_id'])){
    extract($_POST);
    if($qry=mysqli_query($con, "SELECT * FROM student_courses WHERE id=$delete_student_course_id;")){
      if(mysqli_num_rows($qry) == 1){
        if(mysqli_query($con, "DELETE FROM student_courses WHERE Id=$delete_student_course_id;"))
        $msg = [
          "type" => "success",
          "msg" => "Student-Course Deleted Successfully!",
        ];
        else $msg = [
          "type" => "danger",
          "msg" => "Error while Deleting student_course!",
        ];
      } else $msg = [
        "type" => "danger",
        "msg" => "Student-Course Does not Exists!",
      ];
    } else $msg = [
      "type" => "danger",
      "msg" => "Unable to Confirm Student-Course!",
    ];
  }

  // Fetch Student-Courses
  $student_courses = [];
  if($qry=mysqli_query($con, "SELECT student_courses.id, student_id, fname, lname, course_id, title as course FROM student_courses INNER JOIN users ON student_id=users.id INNER JOIN courses ON course_id=courses.id;"))
  while($student_course=mysqli_fetch_assoc($qry))
  $student_courses[]=$student_course;
  else die("Unable to fetch student_courses from database");

  // Fetch Students
  $students = [];
  if($qry=mysqli_query($con, "SELECT id, fname, lname FROM users WHERE role='s';"))
  while($student=mysqli_fetch_assoc($qry))
  $students[]=$student;
  else die("Unable to fetch students from database");

  // Fetch Courses
  $courses = [];
  if($qry=mysqli_query($con, "SELECT id, title FROM courses;"))
  while($course=mysqli_fetch_assoc($qry))
  $courses[]=$course;
  else die("Unable to fetch courses from database");

  include "layouts/dashboard/dashboard_start.php";
?>

<div class="jumbotron">
  <?php
    include "includes/alert.php";
  ?>
  <h1 class="display-4">Student-Courses</h1>
  <p class="lead">
    Manage your database student_courses in followings:
  </p>
  <hr class="my-5">
  <table id="data_table" class="data_table table table-striped table-bordered" style="width:100%">
    <thead>
      <th>#</th>
      <th>Student</th>
      <th>Course</th>
      <th>Actions</th>
    </thead>
    <tbody>
      <?php
        $counter=0;
        foreach($student_courses as $student_course){
          extract($student_course);
          $counter++;
          ?>
            <tr>
              <td><?=$counter?></td>
              <td><?=$fname." ".$lname?></td>
              <td><?=$course?></td>
              <td>
                <form action="" method="post" class="d-inline-block">
                  <input type="hidden" name="delete_student_course_id" value="<?=$id?>">
                  <button type="submit" class="btn btn-danger">
                    <i class="fa fa-trash"></i>
                  </button>
                </form>
                
                <!-- Update Modal Trigger -->
                <button type="button" class="btn btn-success" data-bs-toggle="modal" data-bs-target="#edit_student_course_<?=$id?>">
                  <i class="fa fa-edit"></i>
                </button>
                <!-- Update Modal -->
                <form class="modal fade" id="edit_student_course_<?=$id?>" tabindex="-1" aria-hidden="true" action="" method="post">
                  <input type="hidden" name="update_student_course_id" value="<?=$id?>">
                  <div class="modal-dialog modal-dialog-centered">
                    <div class="modal-content">
                      <div class="modal-header">
                        <h5 class="modal-title">Update Student-Course</h5>
                        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                      </div>
                      <div class="modal-body">
                        <div class="row">
                          <div class="col-md-6">
                            <div class="form-group">
                              <label>Student</label>
                              <select name="student" class="form-control" required>
                                <?php
                                  foreach($students as $student){
                                    ?><option value="<?=$student['id']?>"<?=$student_id==$student['id']?" selected":""?>><?=$student['fname']." ".$student['lname']?></option><?php
                                  }
                                ?>
                              </select>
                            </div>
                          </div>
                          <div class="col-md-6">
                            <div class="form-group">
                              <label for="course">Course</label>
                              <select name="course" id="course" class="form-control" required>
                                <?php
                                  foreach($courses as $course){
                                    ?><option value="<?=$course['id']?>"<?=$course_id==$course['id']?" selected":""?>><?=$course['title']?></option><?php
                                  }
                                ?>
                              </select>
                            </div>
                          </div>
                        </div>
                      </div>
                      <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                        <button type="submit" class="btn btn-primary">Save changes</button>
                      </div>
                    </div>
                  </div>
                </form>
              </td>
            </tr>
          <?php
        }
      ?>
    </tbody>
    <tfoot>
      <th>#</th>
      <th>Student</th>
      <th>Course</th>
      <th>Actions</th>
    </tfoot>
  </table>
</div>

<div class="jumbotron">
  <h1 class="display-4">Add new Student-Course</h1>
  <p class="lead">
    Create New Student-Course
  </p>
  <hr>
  <form action="" method="post" class="d-block">
    <input type="hidden" name="add_student_course" value="true">
    <div class="row">
      <div class="col-md-6">
        <div class="form-group">
          <label for="student">Student</label>
          <select name="student" id="student" class="form-control" required>
            <option value="" selected class="d-none">Select Student</option>
            <?php
              foreach($students as $student){
                ?><option value="<?=$student['id']?>"><?=$student['fname']." ".$student['lname']?></option><?php
              }
            ?>
          </select>
        </div>
      </div>
      <div class="col-md-6">
        <div class="form-group">
          <label for="course">Course</label>
          <select name="course" id="course" class="form-control" required>
            <option value="" selected class="d-none">Select Course</option>
            <?php
              foreach($courses as $course){
                ?><option value="<?=$course['id']?>"><?=$course['title']?></option><?php
              }
            ?>
          </select>
        </div>
      </div>
    </div>
    <br>
    <button type="submit" class="btn btn-success">
      <i class="fa fa-plus"></i>
      Add
    </button>
    <button type="reset" class="btn btn-secondary">Clear</button>
  </form>
</div>

<?php
  include "layouts/dashboard/dashboard_end.php";
?>