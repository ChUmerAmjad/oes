<?php
  if(!isset($con)) require "includes/con.php";
  if(!isset($user)) require "includes/auth.php";

  if(!in_array($user['role'], ['a', 't']))
  header('location: login.php');

  // Add User
  if(isset($_POST['add_user'])){
    extract($_POST);
    if($qry=mysqli_query($con, "SELECT * FROM users WHERE email = '$email';")){
      if(mysqli_num_rows($qry) == 0){
        if(mysqli_query($con, "INSERT INTO users(email, password, role, fname, lname, cnic) VALUES ('$email', '$password', '$role', '$fname', '$lname', '$cnic');"))
        $msg = [
          "type" => "success",
          "msg" => "User Registered Successfully!",
        ];
        else $msg = [
          "type" => "danger",
          "msg" => "Error while inserting user!",
        ];
      } else $msg = [
        "type" => "danger",
        "msg" => "Email Already Registered!",
      ];
    }
  }

  // Update user
  if(isset($_POST['update_user_id'])){
    extract($_POST);
    if($qry=mysqli_query($con, "SELECT * FROM users WHERE id=$update_user_id;")){
      if(mysqli_num_rows($qry) == 1){
        if($qry=mysqli_query($con, "SELECT * FROM users WHERE email='$email' AND id!=$update_user_id;")){
          if(mysqli_num_rows($qry) == 0){
            if(mysqli_query($con, "UPDATE users SET email='$email', password='$password', role='$role', fname='$fname', lname='$lname', cnic='$cnic' WHERE id=$update_user_id;"))
            $msg = [
              "type" => "success",
              "msg" => "User Updated Successfully!",
            ];
            else $msg = [
              "type" => "danger",
              "msg" => "Error while Updating user!",
            ];
          } else $msg = [
            "type" => "danger",
            "msg" => "Email Already Registered!",
          ];
        } else $msg = [
          "type" => "danger",
          "msg" => "Unable to Confirm Email!",
        ];
      } else $msg = [
        "type" => "danger",
        "msg" => "User Does not Exists!",
      ];
    } else $msg = [
      "type" => "danger",
      "msg" => "Unable to Confirm User!",
    ];
  }

  // Delete User
  if(isset($_POST['delete_user_id'])){
    extract($_POST);
    if($qry=mysqli_query($con, "SELECT * FROM users WHERE id=$delete_user_id;")){
      if(mysqli_num_rows($qry) == 1){
        if(mysqli_query($con, "DELETE FROM users WHERE Id=$delete_user_id;"))
        $msg = [
          "type" => "success",
          "msg" => "User Deleted Successfully!",
        ];
        else $msg = [
          "type" => "danger",
          "msg" => "Error while Deleting user!",
        ];
      } else $msg = [
        "type" => "danger",
        "msg" => "User Does not Exists!",
      ];
    } else $msg = [
      "type" => "danger",
      "msg" => "Unable to Confirm User!",
    ];
  }


  // Fetch Users
  $users = [];
  if($qry=mysqli_query($con, "SELECT * FROM users WHERE role != 'a';"))
  while($_user=mysqli_fetch_assoc($qry))
  $users[]=$_user;
  else die("Unable to fetch users from database");

  include "layouts/dashboard/dashboard_start.php";
?>

<div class="jumbotron">
  <?php
    include "includes/alert.php";
  ?>
  <h1 class="display-4">Users</h1>
  <p class="lead">
    Manage your database users in followings:
  </p>
  <hr class="my-5">
  <table id="data_table" class="data_table table table-striped table-bordered" style="width:100%">
    <thead>
      <th>#</th>
      <th>First Name</th>
      <th>Last Name</th>
      <th>Email Address</th>
      <th>CNIC / B-Form</th>
      <th>Role</th>
      <th>Actions</th>
    </thead>
    <tbody>
      <?php
        $counter=0;
        foreach($users as $user){
          extract($user);
          $counter++;
          ?>
            <tr>
              <td><?=$counter?></td>
              <td><?=$fname?></td>
              <td><?=$lname?></td>
              <td><?=$email?></td>
              <td><?=$cnic?></td>
              <td><?=$role=='s'?"Student":($role=='t'?"Teacher":"Admin")?></td>
              <td>
                <form action="" method="post" class="d-inline-block">
                  <input type="hidden" name="delete_user_id" value="<?=$id?>">
                  <button type="submit" class="btn btn-danger">
                    <i class="fa fa-trash"></i>
                  </button>
                </form>
                
                <!-- Update Modal Trigger -->
                <button type="button" class="btn btn-success" data-bs-toggle="modal" data-bs-target="#edit_user_<?=$id?>">
                  <i class="fa fa-edit"></i>
                </button>
                <!-- Update Modal -->
                <form class="modal fade" id="edit_user_<?=$id?>" tabindex="-1" aria-hidden="true" action="" method="post">
                  <input type="hidden" name="update_user_id" value="<?=$id?>">
                  <div class="modal-dialog modal-dialog-centered">
                    <div class="modal-content">
                      <div class="modal-header">
                        <h5 class="modal-title">Update User</h5>
                        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                      </div>
                      <div class="modal-body">
                        <div class="row">
                          <div class="col-md-6">
                            <div class="form-group">
                              <label for="update_<?=$id?>_fname">First Name</label>
                              <input type="text" class="form-control" name="fname" id="update_<?=$id?>_fname" placeholder="First Name" value="<?=$fname?>" required>
                            </div>
                          </div>
                          <div class="col-md-6">
                            <div class="form-group">
                              <label for="update_<?=$id?>_lname">Last Name</label>
                              <input type="text" class="form-control" name="lname" id="update_<?=$id?>_lname" placeholder="Last Name" value="<?=$lname?>" required>
                            </div>
                          </div>
                          <div class="col-md-6">
                            <div class="form-group">
                              <label for="update_<?=$id?>_email">Email Address</label>
                              <input type="text" class="form-control" name="email" id="update_<?=$id?>_email" placeholder="Email Address" value="<?=$email?>" required>
                            </div>
                          </div>
                          <div class="col-md-6">
                            <div class="form-group">
                              <label for="update_<?=$id?>_cnic">CNIC / B-Form</label>
                              <input type="text" class="form-control" name="cnic" id="update_<?=$id?>_cnic" placeholder="CNIC / B-Form" value="<?=$cnic?>" required>
                            </div>
                          </div>
                          <div class="col-md-6">
                            <div class="form-group">
                              <label for="update_<?=$id?>_password">First Password</label>
                              <input type="password" class="form-control" name="password" id="update_<?=$id?>_password" placeholder="password" value="<?=$password?>" required>
                            </div>
                          </div>
                          <div class="col-md-6">
                            <div class="form-group">
                              <label for="update_<?=$id?>_role">Role</label>
                              <select name="role" id="update_<?=$id?>_role" class="form-control" required>
                                <option value="s"<?=$role=='s'?" selected":""?>>Student</option>
                                <option value="t"<?=$role=='t'?" selected":""?>>Teacher</option>
                              </select>
                            </div>
                          </div>
                        </div>
                      </div>
                      <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                        <button type="submit" class="btn btn-primary">Save changes</button>
                      </div>
                    </div>
                  </div>
                </form>
              </td>
            </tr>
          <?php
        }
      ?>
    </tbody>
    <tfoot>
      <th>#</th>
      <th>First Name</th>
      <th>Last Name</th>
      <th>Email Address</th>
      <th>CNIC / B-Form</th>
      <th>Role</th>
      <th>Actions</th>
    </tfoot>
  </table>
</div>

<div class="jumbotron">
  <h1 class="display-4">Create new User</h1>
  <p class="lead">
    Create New User Account
  </p>
  <hr>
  <form action="" method="post">
    <input type="hidden" name="add_user" value="true">
    <div class="row">
      <div class="col-md-6">
        <div class="form-group">
          <label for="fname">First Name</label>
          <input type="text" class="form-control" name="fname" id="fname" placeholder="First Name" required>
        </div>
      </div>
      <div class="col-md-6">
        <div class="form-group">
          <label for="lname">Last Name</label>
          <input type="text" class="form-control" name="lname" id="lname" placeholder="Last Name" required>
        </div>
      </div>
      <div class="col-md-6">
        <div class="form-group">
          <label for="email">Email Address</label>
          <input type="text" class="form-control" name="email" id="email" placeholder="Email Address" required>
        </div>
      </div>
      <div class="col-md-6">
        <div class="form-group">
          <label for="cnic">CNIC / B-Form</label>
          <input type="text" class="form-control" name="cnic" id="cnic" placeholder="CNIC / B-Form" required>
        </div>
      </div>
      <div class="col-md-6">
        <div class="form-group">
          <label for="password">First Password</label>
          <input type="password" class="form-control" name="password" id="password" placeholder="password" value="12345678" required>
        </div>
      </div>
      <div class="col-md-6">
        <div class="form-group">
          <label for="role">Role</label>
          <select name="role" id="role" class="form-control" required>
            <!-- <option value="" selected class="d-none">Role</option> -->
            <option value="s" selected>Student</option>
            <option value="t">Teacher</option>
          </select>
        </div>
      </div>
    </div>
    <br>
    <button type="submit" class="btn btn-success">
      <i class="fa fa-user-plus"></i>
      Register
    </button>
    <button type="reset" class="btn btn-secondary">Clear</button>
  </form>
</div>

<?php
  include "layouts/dashboard/dashboard_end.php";
?>