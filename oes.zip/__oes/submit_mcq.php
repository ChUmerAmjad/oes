<?php
  if(!isset($con)) require "includes/con.php";
  if(!isset($user)) require "includes/auth.php";

  if(in_array($user['role'], ['a', 't']))
  header('location: dashboard.php');
  elseif($user['role']!='s')
  header('location: login.php');
  
  $res = ['status' => 0];
  
  if(isset($_POST['exam_submission_id']) && isset($_POST['mcq_id']) && isset($_POST['selected_option'])){
    if($qry=mysqli_query($con, "SELECT count(id) FROM exam_submission_mcqs WHERE exam_submission_id='".$_POST['exam_submission_id']."' AND question_id='".$_POST['mcq_id']."';")){
      if(mysqli_fetch_row($qry)[0]==0){
        if(mysqli_query($con, "INSERT INTO exam_submission_mcqs(exam_submission_id, question_id, selected_option) VALUES ('".$_POST['exam_submission_id']."', '".$_POST['mcq_id']."', '".$_POST['selected_option']."')")){
          $res['status']=1;
          mysqli_query($con, "UPDATE exam_submissions SET lm_date=CURRENT_DATE, lm_time=CURRENT_TIME where id='".$_POST['exam_submission_id']."';");
        }
        else $res["error"]="Unable to Submit MCQ!";
      } else $res["error"]="MCQ Already Submitted!";
    } else $res["error"]="Unable to confirm MCQ Submission!";
  } else $res["error"]="Invalid data!";

  echo json_encode($res);

?>