let elements = document.getElementsByClassName('counter-update');

const putCount = (count_str) => {
  for(let i=0 ; i <elements.length ; i++)
  elements[i].innerText = count_str;
};

const submit = () => document.getElementById('submit_exam_trigger').click();

const initializeCounter = (start, h, m, s) => {
  current = new Date;
  diff = new Date(Date.parse(`Thu Jan 01 1970 ${h}:${m}:${s}`) - new Date(current - start));

  if(diff > 0)
  setInterval(() => {
    current = new Date;
    diff = new Date(Date.parse(`Thu Jan 01 1970 ${h}:${m}:${s}`) - new Date(current - start));

    if(diff.getTime() < 0)
    submit();
    else putCount(`${diff.getHours()}h ${diff.getMinutes()}m ${diff.getSeconds()}s`);
  }, 1000);
  else submit();
};

const submit_mcq = (button, exam_submission_id, mcq_id) => {
  selected_option=null;
  if(document.getElementById(`mcq_${mcq_id}_option_a`).checked)
  selected_option='a';
  else if(document.getElementById(`mcq_${mcq_id}_option_b`).checked)
  selected_option='b';
  else if(document.getElementById(`mcq_${mcq_id}_option_c`).checked)
  selected_option='c';
  else selected_option='d';

  $.ajax({
    url : 'submit_mcq.php',
    method: 'POST',
    data: {
      exam_submission_id,
      mcq_id,
      selected_option,
    },
    success: (r) => {
      try {
        r = JSON.parse(r);
      } catch (error) {
        alert("Invalid Data From Server");
      }
      if(r.status){
        button.disabled=true;
        button.title="Already Submitted";
        document.getElementById(`mcq_${mcq_id}_option_a`).disabled = true;
        document.getElementById(`mcq_${mcq_id}_option_b`).disabled = true;
        document.getElementById(`mcq_${mcq_id}_option_c`).disabled = true;
        document.getElementById(`mcq_${mcq_id}_option_d`).disabled = true;
        document.getElementById(`mcq-${mcq_id}`).classList.add("bg-success");
      } else alert("Unable to Submit Answer at the moment!");
    },
    error: () => confirm("Check your internet and click Ok to Retry.")?submit_mcq(button, mcq_id, exam_id):false
  });
};