<?php
  if(!isset($con)) require "includes/con.php";
  if(!isset($user)) require "includes/auth.php";

  if(in_array($user['role'], ['a', 't']))
  header('location: dashboard.php');
  elseif($user['role']!='s')
  header('location: login.php');
  
  if(isset($_POST['submition_id']))
  if(!mysqli_query($con, "UPDATE exams_submissions SET submission_status=1, submission_comment='".(isset($_POST['submission_comment'])?$_POST['submission_comment']:"")."', lm_date=CURRENT_DATE, lm_time=CURRENT_TIME WHERE id='".$_POST['submition_id']."' AND submission_status=0;"))
  die("Unable to Subimt Exam!");
  
  header("location: index.php");
?>