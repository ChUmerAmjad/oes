<?php
  if(!isset($con)) require "includes/con.php";
  if(!isset($user)) require "includes/auth.php";

  if(in_array($user['role'], ['a', 't']))
  header('location: dashboard.php');
  elseif($user['role']!='s')
  header('location: login.php');

  require "layouts/student/layout_start.php";
  include "${prefix}welcome.php";
?>

<div class="row p-5">
  <div class="col-12">
    <h1 class="display-4">Available Exams:</h1>
    <p class="lead">
      Select Exam to Submit Online:
    </p>
    <hr class="my-4">
    <div class="row">
      <?php
        $exams = [];
        mysqli_query($con, "UPDATE exams SET status=2 WHERE end_date < CURRENT_DATE;");
        if($qry=mysqli_query($con, "SELECT *, (exams.subjective_marks + ((SELECT count(id) FROM exam_mcqs WHERE exam_id=exams.id) * exams.mcq_marks)) AS total_marks, (SELECT count(id) FROM exams_submissions WHERE exam_id=exams.id AND student_id=".$user['id'].") as submissions FROM (SELECT exams.id, subjective_marks, mcq_marks, users.fname, users.lname, subject, exam_type, start_date, end_date, time_h, time_m, time_s, status FROM exams INNER JOIN users ON teacher_id=users.id INNER JOIN subjects ON subject_id=subjects.id WHERE start_date <= CURRENT_DATE AND course_id IN (SELECT course_id FROM student_courses WHERE student_courses.student_id=".$user['id'].")) AS exams;")){
          while($exam = mysqli_fetch_assoc($qry))
          $exams[]=$exam;
        }
        if(count($exams)>0) foreach($exams as $exam){
          extract($exam);
          $submission=false;
          if($submissions>0){
            if($qry=mysqli_query($con, "SELECT id, type, marks, (SELECT COUNT(exam_submission_mcqs.id) FROM exam_submission_mcqs INNER JOIN exam_mcqs ON exam_submission_mcqs.question_id=exam_mcqs.id WHERE exam_submission_id=exams_submissions.id AND exam_submission_mcqs.selected_option=exam_mcqs.correct) * $mcq_marks + marks as total_obt_marks, date, time, CURRENT_DATE as cd, CURRENT_TIME as ct, submission_status, grading_status, lm_date, lm_time FROM exams_submissions WHERE exam_id='$id';")){
              $submission = mysqli_fetch_assoc($qry);
            } else die("Unable to fetch Exam Submission!".mysqli_error($con));
          }


          ?>
            <div class="col-xl-3 col-lg-4 col-md-6">
              <div class="card">
                <ul class="list-group list-group-flush">
                  <li class="list-group-item"><b>Teacher:</b> <?=$fname." ".$lname?></li>
                  <li class="list-group-item"><b>Subject:</b> <?=$subject?></li>
                  <li class="list-group-item"><b>Exam Type:</b> <?=$exam_type=='b'?'<br>Both (Anual & Supply)':($exam_type=='a'?'Annual':'Supply')?></li>
                  <li class="list-group-item"><b>Status:</b> <?=$status==0?"<span class='text-danger'>Hidden</span>":($status==1?"<span class='text-success'>Active</span>":"<span class='text-danger'>Closed</span>")?></li>
                  <li class="list-group-item"><b>Announced At:</b> <?=$start_date?></li>
                  <li class="list-group-item"><b>Due Date:</b> <?=$end_date?></li>
                  <li class="list-group-item"><b>Total Marks:</b> <?=$total_marks?> (S:<?=$subjective_marks?>, M:<?=$total_marks-$subjective_marks?>)</li>
                  <li class="list-group-item"><b>Duration:</b> <?="${time_h}h ${time_m}m ${time_s}s"?></li>
                  <?php
                    $time_over = false;
                    $due_date = strtotime($end_date);
                    $current = strtotime($submission['cd']." ".$submission['ct']);
                    if($due_date<=$current)
                    $time_over = true;

                    if(!$submission){
                      ?>
                        <li class="list-group-item">
                          <b>Submission Status:</b> <br>
                          <span class='text-danger'>Not Submitted<span>
                        </li>
                      <?php
                    } else {
                      $started_at = strtotime($submission['date']." ".$submission['time']);
                      $duration = strtotime("1970-01-01 "."${time_h}:${time_m}:${time_s}");

                      $remaining=0;
                      if($time_over==false)
                      $remaining = $started_at+$duration-$current;
                      else $remaining = 0;

                      if(!$time_over && ($remaining <= 0))
                      $time_over = true;

                      if($submission['submission_status']==1){
                        ?>
                          <li class="list-group-item">
                            <b>Started At:</b> <br>
                            <span><?=$submission['date']." ".$submission['time']?></span>
                          </li>
                          <li class="list-group-item">
                            <b>Submission Status:</b> <br>
                            <span class='text-primary'>Submitted<span>
                          </li>
                          <li class="list-group-item">
                            <b>Last Modified:</b> <br>
                            <b><?=$submission['lm_date']." ".$submission['lm_time']?></b>
                          </li>
                          <?php
                            if($submission['grading_status']==1){
                              ?>
                                <li class="list-group-item">
                                  <b>Grading Status:</b> <br>
                                  <span class='text-success'>Marked<span>
                                </li>
                                <li class="list-group-item">
                                  <b>Total Marks:</b> <br>
                                  <span class='text-success'><?=$submission['total_obt_marks']?></span>
                                </li>
                              <?php
                            } else {
                              ?>
                                <li class="list-group-item">
                                  <b>Grading Status:</b> <br>
                                  <span class='text-primary'>Under-Process<span>
                                </li>
                              <?php
                            }
                          ?>
                        <?php
                      } elseif($time_over) {
                        mysqli_query($con, "UPDATE exams_submissions SET submission_status=1 WHERE id='".$submission['id']."' AND submission_status=0;");
                        ?>
                          <li class="list-group-item">
                            <b>Submission Status:</b> <br>
                            <span class='text-primary'>Submitted<span>
                          </li>
                          <?php
                            if($submission['grading_status']==1){
                              ?>
                                <li class="list-group-item">
                                  <b>Grading Status:</b> <br>
                                  <span class='text-success'>Marked<span>
                                </li>
                                <li class="list-group-item">
                                  <b>Marks:</b> <br>
                                  <span class='text-success'><?=$submission['marks']?></span>
                                </li>
                              <?php
                            } else {
                              ?>
                                <li class="list-group-item">
                                  <b>Grading Status:</b> <br>
                                  <span class='text-primary'>Under-Process<span>
                                </li>
                              <?php
                            }
                          ?>
                        <?php
                      } else {
                        ?>
                          <li class="list-group-item">
                            <b>Submission Status:</b> <br>
                            <span class='text-danger'>Not Submitted<span>
                          </li>
                          <li class="list-group-item">
                            <b>Time Remaining:</b> <br>
                            <span class='text-danger'><?=date("H:i:s", $remaining)?></span>
                          </li>
                        <?php
                      }
                    }
                  ?>
                </ul>
                <div class="card-body">
                  <?php
                    if(!$time_over && !$submission){
                      ?>
                        <form action="exam_submission.php" method="post" class="text-right">
                          <input type="hidden" name="exam_id" value="<?=$id?>">
                          <select name="type" id="type" class="form-control" required>
                            <?php
                              if($exam_type=='b'){
                                ?>
                                  <option value="" class="d-none">Select Type</option>
                                  <option value="a">Annual</option>
                                  <option value="s">Supply</option>
                                <?php
                              }elseif($exam_type=='s'){
                                ?><option value="s">Supply</option><?php
                              } else {
                                ?><option value="a">Annual</option><?php
                              }
                            ?>
                          </select>
                          <br>
                          <button type="submit" class="btn btn-success"<?=$status!=1||($time_over)?" disabled":""?>>
                            Start Exam
                            &DoubleRightArrow;
                          </button>
                        </form>
                      <?php
                    } else {
                      ?>
                        <form action="exam_submission.php" method="post" class="text-right">
                          <input type="hidden" name="exam_id" value="<?=$id?>">
                          <input type="hidden" name="type" value="<?=$submission['type']?>">
                          <button type="submit" class="btn btn-success"<?=$status==0||(($submission['submission_status']!=1) && $time_over)?" disabled":""?>>
                            Go To Exam
                            &DoubleRightArrow;
                          </button>
                        </form>
                      <?php
                    }
                  ?>
                </div>
              </div>
            </div>
          <?php
        }
        else {
          ?>
            <div class="col-12">
              <p class="lead">
                No Exams Available for You.
              </p>
            </div>
          <?php
        }
      ?>
    </div>
  </div>
</div>

<?php
  require "layouts/student/layout_end.php";
?>