<?php
  require "includes/auth.php";
  logout();
  header("location: login.php");
?>