<?php
  if(!isset($con)) require "includes/con.php";
  if(!isset($user)) require "includes/auth.php";

  if(!in_array($user['role'], ['a', 't']))
  header('location: login.php');
  elseif($user['role']!='a')
  header('location: dashboard.php');

  // Update Exam Marks
  if(isset($_POST['mark_questions'])){
    extract($_POST);
    if($qry=mysqli_query($con, "SELECT * FROM exams_submissions WHERE id=$exam_submission_id;")){
      if(mysqli_num_rows($qry) == 1){
        if(mysqli_query($con, "UPDATE exams_submissions SET marks='$marks', grading_status=1 WHERE id=$exam_submission_id;"))
        $msg = [
          "type" => "success",
          "msg" => "Exam Submission Marked Successfully!",
        ];
        else $msg = [
          "type" => "danger",
          "msg" => "Error while Marking Exam Submission!",
        ];
      } else $msg = [
        "type" => "danger",
        "msg" => "Exam Submission Does not Exists!",
      ];
    } else $msg = [
      "type" => "danger",
      "msg" => "Unable to Confirm Exam Submission!".mysqli_error($con),
    ];
  }

  // Fetch Exam Submissions
  $exam_submissions = [];
  if($qry=mysqli_query($con, "SELECT exams_submissions.id, exam_id, student_id, teacher_id, subject_id, course_id, (SELECT fname FROM users WHERE users.id=teacher_id) as tfname, (SELECT lname FROM users WHERE users.id=teacher_id) as tlname, fname, lname, subject, courses.title as course, type, marks, subjective_marks, mcq_marks, (subjective_marks + ((SELECT count(id) FROM exam_mcqs WHERE exam_id=exams.id) * exams.mcq_marks)) AS total_marks, (SELECT COUNT(exam_submission_mcqs.id) FROM exam_submission_mcqs INNER JOIN exam_mcqs ON question_id=exam_mcqs.id WHERE exam_submission_id=exams_submissions.id AND selected_option=correct) AS correct_mcqs, date, time, lm_date, lm_time, submission_status, grading_status, status, submission_comment FROM exams_submissions INNER JOIN exams ON exam_id=exams.id INNER JOIN users ON student_id=users.id INNER JOIN subjects ON subject_id=subjects.id INNER JOIN courses ON course_id=courses.id;"))
  while($submission=mysqli_fetch_assoc($qry))
  $exam_submissions[]=$submission;

  include "layouts/dashboard/dashboard_start.php";
?>

<div class="jumbotron">
  <?php
    include "includes/alert.php";
  ?>
  <h1 class="display-4">Exams' Submissions:</h1>
  <p class="lead">
    Manage all exams' submissions in followings:
  </p>
  <hr class="my-5">
  <div style="overflow: auto;">
    <table id="data_table" class="data_table table table-striped table-bordered"  style="width:100%; min-width: 3000px;">
      <thead>
        <th>#</th>
        <th>Teacher</th>
        <th>Course</th>
        <th>Subject</th>
        <th>Student</th>
        <th>Subjective Marks</th>
        <th>Objective Marks</th>
        <th>Total Marks</th>
        <th>Type</th>
        <th>Started At</th>
        <th>Last Modified</th>
        <th>Exam Status</th>
        <th>Submission Status</th>
        <th>Grading Status</th>
        <th>Obtained Subjective</th>
        <th>Obtained Objective</th>
        <th>Obtained Total</th>
        <th>Comment</th>
        <th>Actions</th>
      </thead>
      <tbody>
        <?php
          $counter=0;
          foreach($exam_submissions as $submission){
            extract($submission);
            $counter++;
            ?>
              <tr>
                <td><?=$counter?></td>
                <td><?=$tfname." ".$tlname?></td>
                <td><?=$course?></td>
                <td><?=$subject?></td>
                <td><?=$fname." ".$lname?></td>
                <td><?=$subjective_marks?></td>
                <td><?=$total_marks-$subjective_marks." ($mcq_marks each)"?></td>
                <td><?=$total_marks?></td>
                <td><?=$type=='b'?'Both':($type=='a'?'Annual':'Supply')?></td>
                <td><?="$date $time"?></td>
                <td><?="$lm_date $lm_time"?></td>
                <td><?=$status==0?"Hidden":($status==1?"Active":"Closed")?></td>
                <td><?=$submission_status==1?"Submitted":"Not Submitted"?></td>
                <td><?=$grading_status==1?"Marked":"Not Marked"?></td>
                <td><?=$marks?></td>
                <td><?=$correct_mcqs*$mcq_marks?></td>
                <td><?=$marks + $correct_mcqs*$mcq_marks?></td>
                <td><?=$submission_comment?></td>
                <td>
                  <!-- MCQs Trigger -->
                  <button type="button" class="btn btn-secondary" data-bs-toggle="modal" data-bs-target="#exam_submission_<?=$id?>_mcqs" title="MCQs">
                    <i class="mdi mdi-checkbox-multiple-marked-outline"></i>
                  </button>

                  <!-- MCQs Modal -->
                  <div class="modal fade" id="exam_submission_<?=$id?>_mcqs" tabindex="-1" aria-hidden="true" action="" method="post">
                    <div class="modal-dialog modal-dialog-centered" style="min-width: 75vw;">
                      <div class="modal-content">
                        <div class="modal-header">
                          <h5 class="modal-title">Exam Submission MCQs</h5>
                          <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                        </div>
                        <div class="modal-body">
                          <div class="jumbotron">
                            <h1>Exam Submission MCQs:</h1>
                            <p class="lead">
                              MCQs Are submitted as follow by Student
                            </p>
                          </div>
                          <hr class="my-3">
                          <table id="data_table3" class="data_table table table-striped table-bordered table-hover table-light" style="width:100%">
                            <thead>
                              <th>#</th>
                              <th>Question</th>
                              <th>A</th>
                              <th>B</th>
                              <th>C</th>
                              <th>D</th>
                              <th>Correct</th>
                              <th>Selected</th>
                              <th>Marked</th>
                            </thead>
                            <tbody>
                              <?php
                                $counter2 = 0;
                                if($qry = mysqli_query($con, "SELECT exam_submission_mcqs.id, question_id, question, option_a, option_b, option_c, option_d, correct, selected_option FROM exam_submission_mcqs INNER JOIN exam_mcqs ON question_id=exam_mcqs.id WHERE exam_submission_id=$id;"))
                                while($exam_submission_mcq=mysqli_fetch_assoc($qry)){
                                  $counter2++;
                                  ?>
                                    <tr>
                                      <td><?=$counter2?></td>
                                      <td><?=$exam_submission_mcq['question']?></td>
                                      <td><?=$exam_submission_mcq['option_a']?></td>
                                      <td><?=$exam_submission_mcq['option_b']?></td>
                                      <td><?=$exam_submission_mcq['option_c']?></td>
                                      <td><?=$exam_submission_mcq['option_d']?></td>
                                      <td><?=strtoupper($exam_submission_mcq['correct'])?></td>
                                      <td><?=strtoupper($exam_submission_mcq['selected_option'])?></td>
                                      <td><?=$exam_submission_mcq['correct']==$exam_submission_mcq['selected_option']?"<span class='text-success'>Correct</span>":"<span class='text-danger'>In-Correct</span>"?></td>
                                    </tr>
                                  <?php
                                }
                              ?>
                            </tbody>
                            <tfoot>
                              <th>#</th>
                              <th>Question</th>
                              <th>A</th>
                              <th>B</th>
                              <th>C</th>
                              <th>D</th>
                              <th>Correct</th>
                              <th>Selected</th>
                              <th>Marked</th>
                            </tfoot>
                          </table>
                        </div>
                        <div class="modal-footer">
                          <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                        </div>
                      </div>
                    </div>
                  </div>

                  <!-- Questions Trigger -->
                  <button type="button" class="btn btn-success" data-bs-toggle="modal" data-bs-target="#exam_submission_<?=$id?>_questions" title="Questions">
                    <i class="mdi mdi-comment-question-outline"></i>
                  </button>

                  <!-- Question Modal -->
                  <div class="modal fade" id="exam_submission_<?=$id?>_questions" tabindex="-1" aria-hidden="true" action="" method="post">
                    <div class="modal-dialog modal-dialog-centered" style="min-width: 75vw;">
                      <div class="modal-content">
                        <div class="modal-header">
                          <h5 class="modal-title">Exam Submission Questions</h5>
                          <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                        </div>
                        <div class="modal-body">
                          <div class="jumbotron">
                            <h1>Exam Submission Questions:</h1>
                            <p class="lead">
                              Following are questions and submissions of student:
                            </p>
                          </div>
                          <hr class="my-3">
                          <table id="data_table2" class="data_table table table-striped table-light table-hover table-bordered" style="width:100%">
                            <thead>
                              <th>#</th>
                              <th>Question</th>
                            </thead>
                            <tbody>
                              <?php
                                $counter2 = 0;
                                if($qry = mysqli_query($con, "SELECT * FROM exam_questions WHERE exam_id='$exam_id'"))
                                while($exam_question=mysqli_fetch_assoc($qry)){
                                  $counter2++;
                                  ?>
                                    <tr>
                                      <td><?=$counter2?></td>
                                      <td><?=$exam_question['question']?></td>
                                    </tr>
                                  <?php
                                }
                              ?>
                            </tbody>
                            <tfoot>
                              <th>#</th>
                              <th>Question</th>
                            </tfoot>
                          </table>
                          <hr class="my-4">
                          <div class="jumbotron">
                            <h1>Uploaded Files</h1>
                            <p class="lead">
                              Student has uploaded following file(s):
                            </p>
                            <hr class="my-4">
                            <table id="data_table2" class="data_table table table-striped table-light table-hover table-bordered" style="width:100%">
                              <thead>
                                <th>#</th>
                                <th>File</th>
                              </thead>
                              <tbody>
                                <?php
                                  $counter2=0;
                                  if($qry2=mysqli_query($con, "SELECT * FROM exam_submission_files WHERE exam_submission_id='$id';"))
                                  while($file=mysqli_fetch_assoc($qry2)){
                                    $counter2++;
                                    ?>
                                      <tr>
                                        <td><?=$counter2?></td>
                                        <td>
                                          <a href="<?=$file['file_src']?>" class="btn btn-primary">View / Download</a>
                                        </td>
                                      </tr>
                                    <?php
                                  }
                                ?>
                              </tbody>
                            </table>
                          </div>
                          <div class="jumbotron">
                            <h1 class="display-4">Mark</h1>
                            <p class="lead">
                              Mark Question:
                            </p>
                            <hr>
                            <form action="" method="POST">
                              <input type="hidden" name="mark_questions" value="true">
                              <input type="hidden" name="exam_submission_id" value="<?=$id?>">
                              <div class="row">
                                <div class="col">
                                  <div class="form-group">
                                    <label for="exam_submission_<?=$id?>_marks">Marks (Subjective Total: <?=$subjective_marks?>):</label>
                                    <input type="number" min="0" max="<?=$subjective_marks?>"<?=$marks!=0?" value='$marks'":""?> name="marks" id="exam_submission_<?=$id?>_marks" class="form-control" placeholder="Marks" reuqired>
                                  </div>
                                </div>
                                <div class="col-auto">
                                  <div class="form-group">
                                    <label>Submit</label>
                                    <button type="submit" class="btn btn-success form-control"<?=$submission_status==0?" disabled":""?>>
                                      <i class="fa fa-edit"></i>
                                      Mark
                                    </button>
                                  </div>
                                </div>
                              </div>
                            </form>
                          </div>
                        </div>
                        <div class="modal-footer">
                          <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                          <!-- <button type="submit" class="btn btn-primary">Save changes</button> -->
                        </div>
                      </div>
                    </div>
                  </div>
                </td>
              </tr>
            <?php
          }
        ?>
      </tbody>
      <tfoot>
        <th>#</th>
        <th>Teacher</th>
        <th>Course</th>
        <th>Subject</th>
        <th>Student</th>
        <th>Subjective Marks</th>
        <th>Objective Marks</th>
        <th>Total Marks</th>
        <th>Type</th>
        <th>Started At</th>
        <th>Last Modified</th>
        <th>Exam Status</th>
        <th>Submission Status</th>
        <th>Grading Status</th>
        <th>Obtained Subjective</th>
        <th>Obtained Objective</th>
        <th>Obtained Total</th>
        <th>Comment</th>
        <th>Actions</th>
      </tfoot>
    </table>
  </div>
</div>

<?php
  include "layouts/dashboard/dashboard_end.php";
?>