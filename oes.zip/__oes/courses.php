<?php
  if(!isset($con)) require "includes/con.php";
  if(!isset($user)) require "includes/auth.php";

  if(!in_array($user['role'], ['a', 't']))
  header('location: login.php');

  // Add Course
  if(isset($_POST['add_course'])){
    extract($_POST);
    if($qry=mysqli_query($con, "SELECT * FROM courses WHERE title = '$title';")){
      if(mysqli_num_rows($qry) == 0){
        if(mysqli_query($con, "INSERT INTO courses(title) VALUES ('$title');"))
        $msg = [
          "type" => "success",
          "msg" => "Course Inserted Successfully!",
        ];
        else $msg = [
          "type" => "danger",
          "msg" => "Error while Inserting course!",
        ];
      } else {
        $msg = [
          "type" => "danger",
          "msg" => "Course Already Added!",
        ];
      }
    }
  }

  // Update course
  if(isset($_POST['update_course_id'])){
    extract($_POST);
    if($qry=mysqli_query($con, "SELECT * FROM courses WHERE id=$update_course_id;")){
      if(mysqli_num_rows($qry) == 1){
        if($qry=mysqli_query($con, "SELECT * FROM courses WHERE title='$title' AND id!=$update_course_id;")){
          if(mysqli_num_rows($qry) == 0){
            if(mysqli_query($con, "UPDATE courses SET title='$title' WHERE id=$update_course_id;"))
            $msg = [
              "type" => "success",
              "msg" => "Course Updated Successfully!",
            ];
            else $msg = [
              "type" => "danger",
              "msg" => "Error while Updating course!",
            ];
          } else $msg = [
            "type" => "danger",
            "msg" => "Course Name Already Exists!",
          ];
        } else $msg = [
          "type" => "danger",
          "msg" => "Unable to Confirm Course Name!",
        ];
      } else $msg = [
        "type" => "danger",
        "msg" => "Course Does not Exists!",
      ];
    } else $msg = [
      "type" => "danger",
      "msg" => "Unable to Confirm Course!",
    ];
  }

  // Delete Course
  if(isset($_POST['delete_course_id'])){
    extract($_POST);
    if($qry=mysqli_query($con, "SELECT * FROM courses WHERE id=$delete_course_id;")){
      if(mysqli_num_rows($qry) == 1){
        if(mysqli_query($con, "DELETE FROM courses WHERE Id=$delete_course_id;"))
        $msg = [
          "type" => "success",
          "msg" => "Course Deleted Successfully!",
        ];
        else $msg = [
          "type" => "danger",
          "msg" => "Error while Deleting course!",
        ];
      } else $msg = [
        "type" => "danger",
        "msg" => "Course Does not Exists!",
      ];
    } else $msg = [
      "type" => "danger",
      "msg" => "Unable to Confirm Course!",
    ];
  }


  // Fetch Courses
  $courses = [];
  if($qry=mysqli_query($con, "SELECT * FROM courses;"))
  while($course=mysqli_fetch_assoc($qry))
  $courses[]=$course;
  else die("Unable to fetch courses from database");

  include "layouts/dashboard/dashboard_start.php";
?>

<div class="jumbotron">
  <?php
    include "includes/alert.php";
  ?>
  <h1 class="display-4">Courses</h1>
  <p class="lead">
    Manage your database courses in followings:
  </p>
  <hr class="my-5">
  <table id="data_table" class="data_table table table-striped table-bordered" style="width:100%">
    <thead>
      <th>#</th>
      <th>Course</th>
      <th>Actions</th>
    </thead>
    <tbody>
      <?php
        $counter=0;
        foreach($courses as $course){
          extract($course);
          $counter++;
          ?>
            <tr>
              <td><?=$counter?></td>
              <td><?=$title?></td>
              <td>
                <form action="" method="post" class="d-inline-block">
                  <input type="hidden" name="delete_course_id" value="<?=$id?>">
                  <button type="submit" class="btn btn-danger">
                    <i class="fa fa-trash"></i>
                  </button>
                </form>
                
                <!-- Update Modal Trigger -->
                <button type="button" class="btn btn-success" data-bs-toggle="modal" data-bs-target="#edit_course_<?=$id?>">
                  <i class="fa fa-edit"></i>
                </button>
                <!-- Update Modal -->
                <form class="modal fade" id="edit_course_<?=$id?>" tabindex="-1" aria-hidden="true" action="" method="post">
                  <input type="hidden" name="update_course_id" value="<?=$id?>">
                  <div class="modal-dialog modal-dialog-centered">
                    <div class="modal-content">
                      <div class="modal-header">
                        <h5 class="modal-title">Update Course</h5>
                        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                      </div>
                      <div class="modal-body">
                        <div class="row">
                          <div class="col-md-12">
                            <div class="form-group">
                              <label for="update_<?=$id?>_title">Course Title</label>
                              <input type="text" class="form-control" name="title" id="update_<?=$id?>_title" placeholder="Course TItle" value="<?=$title?>" required>
                            </div>
                          </div>
                        </div>
                      </div>
                      <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                        <button type="submit" class="btn btn-primary">Save changes</button>
                      </div>
                    </div>
                  </div>
                </form>
              </td>
            </tr>
          <?php
        }
      ?>
    </tbody>
    <tfoot>
      <th>#</th>
      <th>Course</th>
      <th>Actions</th>
    </tfoot>
  </table>
</div>

<div class="jumbotron">
  <h1 class="display-4">Add new Course</h1>
  <p class="lead">
    Create New Course
  </p>
  <hr>
  <form action="" method="post" class="d-block">
    <input type="hidden" name="add_course" value="true">
    <div class="row">
      <div class="col-md-12">
        <div class="form-group">
          <label for="title">Course Title</label>
          <input type="text" class="form-control" name="title" id="title" placeholder="Course Title" required>
        </div>
      </div>
    </div>
    <br>
    <button type="submit" class="btn btn-success">
      <i class="fa fa-book"></i>
      Create
    </button>
    <button type="reset" class="btn btn-secondary">Clear</button>
  </form>
</div>

<?php
  include "layouts/dashboard/dashboard_end.php";
?>